

## 🐍 Seconde plateforme : PyStage (apprentissage de Python)

Parcours Python progressif (20 modules, 168 exercices corrigés automatiquement), des bases
jusqu'à des exercices de cybersécurité (crypto, hachage, journaux, réseau, forensic, défi final).
Le Python s'exécute dans le navigateur, hors ligne.

- accès : `http://IP-DE-LA-VM:8089`
- lancée par le même `docker compose up -d`
- documentation complète : [`python/README.md`](python/README.md)
