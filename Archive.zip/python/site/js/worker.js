/* Worker d'exécution Python (Pyodide). Isolé du reste de la page :
   une boucle infinie ne bloque pas l'interface, le worker est simplement redémarré. */
importScripts('../vendor/pyodide/pyodide.js');

let executer = null;
const pret = (async () => {
  const py = await loadPyodide({ indexURL: new URL('../vendor/pyodide/', self.location).href });
  const src = await (await fetch('harness.py', { cache: 'no-cache' })).text();
  py.runPython(src);
  executer = py.globals.get('executer_json');
  self.postMessage({ type: 'pret', version: py.runPython('import sys; sys.version.split()[0]') });
})().catch(err => self.postMessage({ type: 'echec', message: String(err) }));

self.onmessage = async (e) => {
  await pret;
  const { id, charge } = e.data;
  try {
    const r = executer(JSON.stringify(charge));
    self.postMessage({ type: 'resultat', id, resultat: JSON.parse(r) });
  } catch (err) {
    self.postMessage({ type: 'resultat', id, resultat: {
      sortie: '', tests: null,
      erreur: { type: 'ErreurInterne', message: String(err), ligne: null, explication: '' } } });
  }
};
