/* PyStage — application (routeur, vues, éditeur, progression). */
(function () {
  'use strict';
  const P = window.PS_PARSER, R = window.PS_RUNNER;
  const $ = (s, el = document) => el.querySelector(s);
  const esc = P.esc;
  const vue = $('#vue');
  let COURS = [];          // modules chargés
  let MEMO = '';

  /* ---------------- Progression (localStorage) ---------------- */
  const CLE = 'pystage.v1';
  const charger = () => { try { return JSON.parse(localStorage.getItem(CLE)) || {}; } catch { return {}; } };
  let etat = Object.assign({ nom: '', exos: {}, lues: {}, debut: new Date().toISOString() }, charger());
  const sauver = () => { try { localStorage.setItem(CLE, JSON.stringify(etat)); } catch {} majBarre(); };
  const brouillon = {
    lire: k => { try { return localStorage.getItem('pystage.code.' + k); } catch { return null; } },
    ecrire: k => v => { try { localStorage.setItem('pystage.code.' + k, v); } catch {} },
    effacer: k => { try { localStorage.removeItem('pystage.code.' + k); } catch {} },
  };
  const statut = k => (etat.exos[k] || {}).statut || '';
  const fait = k => ['reussi', 'solution'].includes(statut(k));

  function tousExos() {
    const r = [];
    COURS.forEach(m => m.lecons.forEach(l => l.exercices.forEach(e =>
      r.push({ m, l, e, k: `${m.id}/${l.id}/${e.id}` }))));
    return r;
  }
  function statsModule(m) {
    let n = 0, ok = 0;
    m.lecons.forEach(l => l.exercices.forEach(e => { n++; if (fait(`${m.id}/${l.id}/${e.id}`)) ok++; }));
    return { n, ok };
  }

  /* ---------------- Barre latérale ---------------- */
  function construireMenu() {
    const nav = $('#menu');
    let html = '', partie = null;
    COURS.forEach((m, i) => {
      if (m.partie !== partie) { partie = m.partie; html += `<div class="menu-partie">${esc(partie)}</div>`; }
      html += `<a href="#/module/${m.id}" data-mod="${m.id}"><span class="num">${String(i + 1).padStart(2, '0')}</span><span class="t">${esc(m.titre)}</span><span class="pc" data-pc="${m.id}"></span></a>`;
    });
    nav.innerHTML = html;
    majBarre();
  }
  function majBarre() {
    const tout = tousExos(); const ok = tout.filter(x => fait(x.k)).length;
    const pc = tout.length ? Math.round(100 * ok / tout.length) : 0;
    const b = $('#barre-globale'); if (b) { b.style.width = pc + '%'; }
    const t = $('#txt-globale'); if (t) t.textContent = `${ok} / ${tout.length} exercices`;
    COURS.forEach(m => {
      const s = statsModule(m); const el = document.querySelector(`[data-pc="${m.id}"]`);
      if (el) { el.textContent = s.n ? `${s.ok}/${s.n}` : ''; el.classList.toggle('complet', s.n && s.ok === s.n); }
    });
  }

  /* ---------------- Éditeur ---------------- */
  function creerEditeur(hote, valeur, opts = {}) {
    const cm = CodeMirror(hote, {
      value: valeur, mode: 'python', lineNumbers: true, indentUnit: 4, tabSize: 4,
      matchBrackets: true, autoCloseBrackets: true, viewportMargin: Infinity,
      extraKeys: {
        Tab: c => c.somethingSelected() ? c.indentSelection('add') : c.replaceSelection('    ', 'end'),
        'Shift-Tab': c => c.indentSelection('subtract'),
        'Ctrl-Enter': () => opts.executer && opts.executer(),
        'Cmd-Enter': () => opts.executer && opts.executer(),
        'Shift-Ctrl-Enter': () => opts.verifier && opts.verifier(),
        'Ctrl-/': c => commenter(c),
      },
    });
    cm.on('change', () => { cm.eachLine(l => cm.removeLineClass(l, 'background', 'ligne-erreur')); });
    if (opts.surChange) cm.on('change', () => opts.surChange(cm.getValue()));
    return cm;
  }
  function commenter(cm) {
    const de = cm.getCursor('from').line, a = cm.getCursor('to').line;
    const lignes = []; for (let i = de; i <= a; i++) lignes.push(cm.getLine(i));
    const tous = lignes.every(l => /^\s*#/.test(l) || l.trim() === '');
    cm.operation(() => { for (let i = de; i <= a; i++) {
      const l = cm.getLine(i);
      const n = tous ? l.replace(/^(\s*)# ?/, '$1') : l.replace(/^(\s*)/, '$1# ');
      cm.replaceRange(n, { line: i, ch: 0 }, { line: i, ch: l.length });
    } });
  }

  function afficherResultat(zone, r, cm, avecTests) {
    let h = '';
    if (r.sortie) h += `<div class="res-titre">Sortie</div><pre class="res-sortie">${esc(r.sortie)}</pre>`;
    if (r.erreur) {
      const e = r.erreur;
      h += `<div class="res-erreur"><div class="err-ligne"><b>${esc(e.type)}</b>${e.message ? ' : ' + esc(e.message) : ''}${e.ligne ? ` <span class="err-pos">ligne ${e.ligne}</span>` : ''}</div>${e.explication ? `<div class="err-expl">${esc(e.explication)}</div>` : ''}</div>`;
      if (e.ligne && cm && e.ligne - 1 < cm.lineCount()) cm.addLineClass(e.ligne - 1, 'background', 'ligne-erreur');
    }
    if (!r.sortie && !r.erreur && !avecTests) h += `<div class="res-vide">Programme terminé, rien n'a été affiché.</div>`;
    if (avecTests && r.tests) {
      const t = r.tests;
      h += t.ok
        ? `<div class="res-ok">Validé. ${t.n} vérification${t.n > 1 ? 's' : ''} réussie${t.n > 1 ? 's' : ''}.</div>`
        : `<div class="res-ko"><div class="ko-titre">Pas encore${t.n ? ` (${t.n} vérification${t.n > 1 ? 's' : ''} passée${t.n > 1 ? 's' : ''})` : ''}</div><pre>${esc(t.message)}</pre></div>`;
    }
    zone.innerHTML = h;
    zone.hidden = false;
  }

  /* Exemple exécutable dans le cours */
  function monterExemple(div, fichiers) {
    const code = div.getAttribute('data-code');
    div.innerHTML = `<div class="ex-ed"></div><div class="ex-barre"><button class="btn petit run">Exécuter</button><button class="btn petit fantome reset" title="Revenir au code d'origine">Rétablir</button><span class="raccourci">Ctrl+Entrée</span></div><div class="resultat" hidden></div>`;
    const zone = $('.resultat', div);
    const go = async () => {
      zone.hidden = false; zone.innerHTML = '<div class="res-vide">Exécution…</div>';
      const r = await R.executer({ code: cm.getValue(), fichiers, entrees: [] });
      afficherResultat(zone, r, cm, false);
    };
    const cm = creerEditeur($('.ex-ed', div), code, { executer: go });
    $('.run', div).onclick = go;
    $('.reset', div).onclick = () => { cm.setValue(code); zone.hidden = true; };
  }

  /* Carte d'exercice */
  function monterExercice(carte, m, l, e, idx) {
    const k = `${m.id}/${l.id}/${e.id}`;
    const fichiers = Object.assign({}, m.fichiers, e.fichiers);
    const noms = Object.keys(fichiers);
    const s0 = statut(k);
    carte.innerHTML = `
      <div class="exo-tete">
        <span class="exo-num">Exercice ${idx + 1}</span>
        <h3>${esc(e.titre)}</h3>
        <span class="badge ${s0}">${libelle(s0)}</span>
      </div>
      <div class="exo-enonce">${P.rendre(e.enonce)}</div>
      ${noms.length ? `<div class="exo-fichiers">Fichiers disponibles : ${noms.map(n => `<button class="lien-fichier" data-f="${esc(n)}">${esc(n)}</button>`).join(' ')}<pre class="apercu" hidden></pre></div>` : ''}
      <div class="exo-ed"></div>
      ${e.entrees !== null ? `<label class="entrees"><span>Entrées pour input() — une valeur par ligne</span><textarea rows="3" spellcheck="false">${esc(e.entrees.join('\n'))}</textarea></label>` : ''}
      <div class="exo-barre">
        <button class="btn run">Exécuter</button>
        <button class="btn primaire verif">Vérifier</button>
        <span class="sep"></span>
        <button class="btn fantome indice" ${e.indices.length ? '' : 'hidden'}>Indice</button>
        <button class="btn fantome sol">Solution</button>
        <button class="btn fantome reset" title="Revenir au code de départ">Réinitialiser</button>
      </div>
      <div class="indices"></div>
      <div class="resultat" hidden></div>
      <div class="solution" hidden></div>`;
    const zone = $('.resultat', carte);
    const ta = $('.entrees textarea', carte);
    const entrees = () => ta ? ta.value.split('\n').filter((x, i, a) => !(i === a.length - 1 && x === '')) : [];

    const run = async () => {
      zone.hidden = false; zone.innerHTML = '<div class="res-vide">Exécution…</div>';
      afficherResultat(zone, await R.executer({ code: cm.getValue(), fichiers, entrees: entrees() }), cm, false);
    };
    const verif = async () => {
      zone.hidden = false; zone.innerHTML = '<div class="res-vide">Vérification…</div>';
      const r = await R.executer({ code: cm.getValue(), fichiers, entrees: entrees(), tests: e.tests || 'pass' });
      afficherResultat(zone, r, cm, true);
      const x = etat.exos[k] || (etat.exos[k] = { statut: '', essais: 0 });
      x.essais++;
      if (r.tests && r.tests.ok) {
        if (x.statut !== 'reussi') { x.statut = x.statut === 'solution' ? 'solution' : 'reussi'; x.date = new Date().toISOString(); }
        zone.insertAdjacentHTML('beforeend', `<button class="btn petit suite">Exercice suivant</button>`);
        $('.suite', zone).onclick = () => allerSuivant(carte);
      } else if (!x.statut) x.statut = 'tente';
      sauver(); majBadge();
      majSol();
    };
    const cm = creerEditeur($('.exo-ed', carte), brouillon.lire(k) ?? e.depart,
      { executer: run, verifier: verif, surChange: brouillon.ecrire(k) });

    function majBadge() { const b = $('.badge', carte); const s = statut(k); b.className = 'badge ' + s; b.textContent = libelle(s); }
    function majSol() {
      const ess = (etat.exos[k] || {}).essais || 0;
      const b = $('.sol', carte);
      const dispo = ess >= 3 || fait(k);
      b.disabled = !dispo;
      b.title = dispo ? '' : `Disponible après 3 vérifications (${ess}/3)`;
    }
    majSol();

    $('.run', carte).onclick = run;
    $('.verif', carte).onclick = verif;
    $('.reset', carte).onclick = () => {
      if (!confirm('Remplacer votre code par le code de départ ?')) return;
      cm.setValue(e.depart); brouillon.effacer(k); zone.hidden = true;
    };
    let nIndice = 0;
    $('.indice', carte).onclick = (ev) => {
      if (nIndice >= e.indices.length) return;
      $('.indices', carte).insertAdjacentHTML('beforeend',
        `<div class="indice-bloc"><span>Indice ${nIndice + 1}/${e.indices.length}</span>${P.rendre(e.indices[nIndice])}</div>`);
      nIndice++;
      if (nIndice >= e.indices.length) ev.target.disabled = true;
      else ev.target.textContent = `Indice suivant`;
    };
    $('.sol', carte).onclick = () => {
      const box = $('.solution', carte);
      if (!box.hidden) { box.hidden = true; return; }
      if (!fait(k) && !confirm("Afficher une solution possible ? L'exercice sera marqué « vu avec solution ».")) return;
      if (!fait(k)) { (etat.exos[k] = etat.exos[k] || { essais: 0 }).statut = 'solution'; sauver(); majBadge(); }
      box.hidden = false;
      box.innerHTML = `<div class="res-titre">Une solution possible</div><div class="sol-ed"></div><div class="sol-note">D'autres écritures sont valables. Comparez avec la vôtre avant de copier quoi que ce soit.</div>`;
      const s = creerEditeur($('.sol-ed', box), e.solution || '# Pas de solution fournie');
      s.setOption('readOnly', true);
    };
    carte.querySelectorAll('.lien-fichier').forEach(b => b.onclick = () => {
      const ap = $('.apercu', carte);
      const n = b.dataset.f;
      if (!ap.hidden && ap.dataset.f === n) { ap.hidden = true; return; }
      const c = fichiers[n];
      ap.textContent = c.startsWith('base64:') ? '(fichier binaire, à ouvrir avec open(..., "rb"))' : c;
      ap.dataset.f = n; ap.hidden = false;
    });
  }
  const libelle = s => ({ reussi: 'Réussi', solution: 'Vu avec solution', tente: 'En cours' }[s] || 'À faire');

  function allerSuivant(carte) {
    const n = carte.nextElementSibling;
    if (n && n.classList.contains('exo')) { n.scrollIntoView({ behavior: 'smooth', block: 'start' }); return; }
    const s = $('.nav-lecons .suiv');
    if (s) location.hash = s.getAttribute('href');
  }

  /* ---------------- Vues ---------------- */
  function vueAccueil() {
    const tout = tousExos(); const ok = tout.filter(x => fait(x.k)).length;
    const prochain = tout.find(x => !fait(x.k));
    const parties = [];
    COURS.forEach(m => { let p = parties.find(x => x.nom === m.partie); if (!p) parties.push(p = { nom: m.partie, mods: [] }); p.mods.push(m); });
    let num = 0;
    vue.innerHTML = `
      <section class="hero">
        <h1>Apprendre Python, de la syntaxe à la sécurité</h1>
        <p>Ce parcours part de zéro et va jusqu'à des outils réels d'analyse : décodage, chiffrement, hachage, lecture de journaux, réseau, forensic. Chaque leçon présente une notion avec des exemples modifiables, puis une série d'exercices corrigés automatiquement.</p>
        <p>Le code s'exécute directement dans le navigateur. Aucune installation n'est nécessaire et rien n'est envoyé sur le réseau.</p>
        <div class="hero-stats">
          <div><b>${COURS.length}</b><span>modules</span></div>
          <div><b>${COURS.reduce((a, m) => a + m.lecons.length, 0)}</b><span>leçons</span></div>
          <div><b>${tout.length}</b><span>exercices</span></div>
          <div><b>${ok}</b><span>réalisés</span></div>
        </div>
        ${prochain ? `<a class="btn primaire grand" href="#/lecon/${prochain.m.id}/${prochain.l.id}">${ok ? 'Reprendre' : 'Commencer'} : ${esc(prochain.m.titre)} — ${esc(prochain.l.titre)}</a>` : '<p><b>Tous les exercices sont faits.</b></p>'}
      </section>
      <section class="mode-emploi">
        <h2>Fonctionnement</h2>
        <ul>
          <li><b>Exécuter</b> (Ctrl+Entrée) lance le code et affiche la sortie. <b>Vérifier</b> (Ctrl+Maj+Entrée) lance en plus les tests de l'exercice.</li>
          <li>Les indices se débloquent un par un. La solution devient accessible après trois vérifications ; l'exercice est alors marqué « vu avec solution ».</li>
          <li>Le code est sauvegardé automatiquement dans le navigateur. On peut fermer la page et reprendre plus tard sur le même poste.</li>
          <li>Les modules s'enchaînent, mais rien n'est verrouillé. La partie Sécurité suppose les deux premières parties acquises.</li>
        </ul>
      </section>
      ${parties.map(p => `
        <section class="partie"><h2>${esc(p.nom)}</h2><div class="grille">
          ${p.mods.map(m => { num++; const s = statsModule(m); const pc = s.n ? Math.round(100 * s.ok / s.n) : 0;
            return `<a class="carte-mod ${s.n && s.ok === s.n ? 'complet' : ''}" href="#/module/${m.id}">
              <span class="cm-num">${String(num).padStart(2, '0')}</span>
              <h3>${esc(m.titre)}</h3><p>${esc(m.resume)}</p>
              <div class="mini-barre"><i style="width:${pc}%"></i></div>
              <span class="cm-stat">${m.lecons.length} leçons · ${s.ok}/${s.n} exercices</span></a>`; }).join('')}
        </div></section>`).join('')}`;
  }

  function vueModule(id) {
    const i = COURS.findIndex(m => m.id === id); const m = COURS[i];
    if (!m) return vue404();
    vue.innerHTML = `
      <nav class="fil"><a href="#/">Accueil</a> / ${esc(m.partie)}</nav>
      <h1><span class="h-num">${String(i + 1).padStart(2, '0')}</span>${esc(m.titre)}</h1>
      <p class="intro">${esc(m.resume)}</p>
      <ol class="liste-lecons">
        ${m.lecons.map(l => { const n = l.exercices.length; const ok = l.exercices.filter(e => fait(`${m.id}/${l.id}/${e.id}`)).length;
          return `<li class="${n && ok === n ? 'complet' : ''}"><a href="#/lecon/${m.id}/${l.id}"><span class="t">${esc(l.titre)}</span><span class="s">${n ? `${ok}/${n}` : 'cours'}</span></a></li>`; }).join('')}
      </ol>
      <div class="nav-mod">
        ${i > 0 ? `<a class="btn fantome" href="#/module/${COURS[i - 1].id}">← ${esc(COURS[i - 1].titre)}</a>` : '<span></span>'}
        ${i < COURS.length - 1 ? `<a class="btn fantome" href="#/module/${COURS[i + 1].id}">${esc(COURS[i + 1].titre)} →</a>` : ''}
      </div>`;
  }

  function vueLecon(mid, lid) {
    const mi = COURS.findIndex(m => m.id === mid); const m = COURS[mi];
    if (!m) return vue404();
    const li = m.lecons.findIndex(l => l.id === lid); const l = m.lecons[li];
    if (!l) return vue404();
    // leçon précédente / suivante, à travers les modules
    const plat = []; COURS.forEach(mm => mm.lecons.forEach(ll => plat.push([mm, ll])));
    const pos = plat.findIndex(([mm, ll]) => mm === m && ll === l);
    const prec = plat[pos - 1], suiv = plat[pos + 1];
    vue.innerHTML = `
      <nav class="fil"><a href="#/">Accueil</a> / <a href="#/module/${m.id}">${esc(m.titre)}</a> / Leçon ${li + 1} sur ${m.lecons.length}</nav>
      <article class="cours"><h1>${esc(l.titre)}</h1>${P.rendre(l.contenu)}</article>
      ${l.exercices.length ? `<h2 class="titre-exos">Exercices</h2>` : ''}
      <div class="exos">${l.exercices.map(() => '<section class="exo"></section>').join('')}</div>
      <nav class="nav-lecons">
        ${prec ? `<a class="btn fantome prec" href="#/lecon/${prec[0].id}/${prec[1].id}">← ${esc(prec[1].titre)}</a>` : '<span></span>'}
        ${suiv ? `<a class="btn suiv" href="#/lecon/${suiv[0].id}/${suiv[1].id}">${suiv[0] !== m ? 'Module suivant : ' + esc(suiv[0].titre) : esc(suiv[1].titre)} →</a>` : ''}
      </nav>`;
    vue.querySelectorAll('.cours .exemple').forEach(d => monterExemple(d, m.fichiers));
    vue.querySelectorAll('.exo').forEach((c, i) => monterExercice(c, m, l, l.exercices[i], i));
    etat.lues[`${m.id}/${l.id}`] = true; sauver();
  }

  function vueBac() {
    const k = '__bac__';
    vue.innerHTML = `
      <h1>Bac à sable</h1>
      <p class="intro">Espace libre pour tester du code. Le contenu est conservé dans le navigateur.</p>
      <div class="exo bac"><div class="exo-ed"></div>
      <label class="entrees"><span>Entrées pour input() — une valeur par ligne</span><textarea rows="3" spellcheck="false"></textarea></label>
      <div class="exo-barre"><button class="btn primaire run">Exécuter</button><span class="raccourci">Ctrl+Entrée</span><span class="sep"></span><button class="btn fantome vider">Vider</button></div>
      <div class="resultat" hidden></div></div>`;
    const zone = $('.resultat', vue); const ta = $('textarea', vue);
    const run = async () => {
      zone.hidden = false; zone.innerHTML = '<div class="res-vide">Exécution…</div>';
      const ent = ta.value === '' ? [] : ta.value.split('\n');
      afficherResultat(zone, await R.executer({ code: cm.getValue(), entrees: ent }), cm, false);
    };
    const cm = creerEditeur($('.exo-ed', vue), brouillon.lire(k) ?? '# Votre code ici\n', { executer: run, surChange: brouillon.ecrire(k) });
    cm.setSize(null, 380);
    $('.run', vue).onclick = run;
    $('.vider', vue).onclick = () => { if (confirm('Effacer le contenu du bac à sable ?')) { cm.setValue(''); zone.hidden = true; } };
  }

  function vueMemo() {
    vue.innerHTML = `<article class="cours memo">${P.rendre(MEMO)}</article>`;
    vue.querySelectorAll('.exemple').forEach(d => monterExemple(d, {}));
  }

  function vueProgression() {
    const tout = tousExos(); const ok = tout.filter(x => fait(x.k)).length;
    const seuls = tout.filter(x => statut(x.k) === 'reussi').length;
    const essais = tout.reduce((a, x) => a + ((etat.exos[x.k] || {}).essais || 0), 0);
    vue.innerHTML = `
      <h1>Progression</h1>
      <label class="champ-nom">Nom <input id="nom" value="${esc(etat.nom || '')}" placeholder="Prénom Nom"></label>
      <div class="hero-stats">
        <div><b>${ok}/${tout.length}</b><span>exercices traités</span></div>
        <div><b>${seuls}</b><span>réussis sans solution</span></div>
        <div><b>${essais}</b><span>vérifications lancées</span></div>
      </div>
      <table class="tab-prog"><thead><tr><th>Module</th><th>Réussis</th><th>Avec solution</th><th>Total</th></tr></thead><tbody>
      ${COURS.map(m => { let r = 0, s = 0, n = 0; m.lecons.forEach(l => l.exercices.forEach(e => { n++; const st = statut(`${m.id}/${l.id}/${e.id}`); if (st === 'reussi') r++; if (st === 'solution') s++; }));
        return `<tr><td><a href="#/module/${m.id}">${esc(m.titre)}</a></td><td>${r}</td><td>${s}</td><td>${n}</td></tr>`; }).join('')}
      </tbody></table>
      <div class="actions">
        <button class="btn" id="exporter">Exporter la progression (JSON)</button>
        <label class="btn fantome">Importer<input type="file" id="importer" accept="application/json" hidden></label>
        <button class="btn fantome danger" id="raz">Tout réinitialiser</button>
      </div>
      <p class="aide">L'export contient les statuts et le code écrit pour chaque exercice. Il permet au tuteur de relire le travail ou de reprendre sur un autre poste.</p>`;
    $('#nom').oninput = ev => { etat.nom = ev.target.value; sauver(); };
    $('#exporter').onclick = () => {
      const code = {}; tout.forEach(x => { const c = brouillon.lire(x.k); if (c !== null) code[x.k] = c; });
      const blob = new Blob([JSON.stringify({ ...etat, code, exporte: new Date().toISOString() }, null, 2)], { type: 'application/json' });
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
      a.download = `pystage-${(etat.nom || 'progression').replace(/\W+/g, '_')}.json`; a.click();
    };
    $('#importer').onchange = async ev => {
      const f = ev.target.files[0]; if (!f) return;
      try {
        const d = JSON.parse(await f.text());
        Object.entries(d.code || {}).forEach(([k, v]) => brouillon.ecrire(k)(v));
        delete d.code; delete d.exporte; etat = Object.assign({ exos: {}, lues: {} }, d); sauver(); vueProgression();
      } catch { alert('Fichier invalide.'); }
    };
    $('#raz').onclick = () => {
      if (!confirm('Effacer toute la progression et tout le code enregistré ?')) return;
      Object.keys(localStorage).filter(k => k.startsWith('pystage.')).forEach(k => localStorage.removeItem(k));
      etat = { nom: '', exos: {}, lues: {}, debut: new Date().toISOString() }; sauver(); vueProgression();
    };
  }

  function vue404() { vue.innerHTML = `<h1>Page introuvable</h1><p><a href="#/">Retour à l'accueil</a></p>`; }

  /* ---------------- Routeur ---------------- */
  function router() {
    const h = location.hash.replace(/^#\/?/, '').split('/');
    document.body.classList.remove('menu-ouvert');
    document.querySelectorAll('#menu a, .liens a').forEach(a => a.classList.toggle('actif',
      (h[0] === 'module' || h[0] === 'lecon') ? a.dataset.mod === h[1] : a.getAttribute('href') === '#/' + h[0]));
    if (!h[0]) vueAccueil();
    else if (h[0] === 'module') vueModule(h[1]);
    else if (h[0] === 'lecon') vueLecon(h[1], h[2]);
    else if (h[0] === 'bac-a-sable') vueBac();
    else if (h[0] === 'memo') vueMemo();
    else if (h[0] === 'progression') vueProgression();
    else vue404();
    window.scrollTo(0, 0);
  }

  /* ---------------- Démarrage ---------------- */
  R.surEtat((s, info) => {
    const el = $('#etat-py');
    el.className = 'etat-py ' + s;
    el.textContent = { chargement: 'Python : chargement…', pret: `Python ${info || ''} prêt`.replace('  ', ' '), occupe: 'Python : exécution…', echec: 'Python : erreur de chargement' }[s];
    if (s === 'pret' && info) el.dataset.v = info;
    if (s === 'pret' && !info && el.dataset.v) el.textContent = `Python ${el.dataset.v} prêt`;
  });

  async function demarrer() {
    R.init();
    $('#burger').onclick = () => document.body.classList.toggle('menu-ouvert');
    $('#voile').onclick = () => document.body.classList.remove('menu-ouvert');
    try {
      const som = await (await fetch('content/sommaire.json', { cache: 'no-cache' })).json();
      const textes = await Promise.all(som.modules.map(f => fetch('content/' + f, { cache: 'no-cache' }).then(r => r.text())));
      COURS = textes.map(P.lireModule);
      MEMO = await (await fetch('content/' + som.memo, { cache: 'no-cache' })).text();
    } catch (err) {
      vue.innerHTML = `<h1>Contenu indisponible</h1><p>Impossible de charger les fichiers du dossier <code>content/</code>. La plateforme doit être servie par un serveur web (voir README).</p><pre>${esc(String(err))}</pre>`;
      return;
    }
    construireMenu();
    window.addEventListener('hashchange', router);
    router();
  }
  demarrer();
})();
