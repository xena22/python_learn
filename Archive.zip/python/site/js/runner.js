/* Pilote du worker Python : file d'attente, délai maximal, redémarrage. */
(function () {
  'use strict';
  const DELAI_MS = 10000;
  let worker = null, pret = false, enCours = null, file = [], seq = 0;
  const abonnes = new Set();

  function signaler(etat, info) { abonnes.forEach(f => f(etat, info)); }

  function demarrer() {
    pret = false;
    signaler('chargement');
    worker = new Worker('js/worker.js');
    worker.onmessage = (e) => {
      const d = e.data;
      if (d.type === 'pret') { pret = true; signaler('pret', d.version); suivant(); }
      else if (d.type === 'echec') signaler('echec', d.message);
      else if (d.type === 'resultat' && enCours && enCours.id === d.id) {
        clearTimeout(enCours.minuterie);
        const t = enCours; enCours = null;
        t.resoudre(d.resultat);
        signaler('pret');
        suivant();
      }
    };
    worker.onerror = (e) => signaler('echec', e.message || 'Erreur du worker');
  }

  function suivant() {
    if (!pret || enCours || !file.length) return;
    enCours = file.shift();
    signaler('occupe');
    enCours.minuterie = setTimeout(() => {
      const t = enCours; enCours = null;
      worker.terminate();
      t.resoudre({ sortie: '', tests: null, erreur: {
        type: 'Délai dépassé',
        message: `exécution interrompue après ${DELAI_MS / 1000} s`,
        ligne: null,
        explication: "Le programme ne s'est pas terminé à temps. Cause la plus fréquente : une boucle while dont la condition reste toujours vraie. L'interpréteur redémarre." } });
      demarrer();
    }, DELAI_MS);
    worker.postMessage({ id: enCours.id, charge: enCours.charge });
  }

  window.PS_RUNNER = {
    executer(charge) {
      if (!worker) demarrer();
      return new Promise(resoudre => { file.push({ id: ++seq, charge, resoudre }); suivant(); });
    },
    surEtat(f) { abonnes.add(f); },
    init() { if (!worker) demarrer(); },
    get pret() { return pret; },
  };
})();
