/* Lecture des fichiers de contenu (content/*.txt) et rendu Markdown simplifié.
   Utilisable dans le navigateur (window.PS_PARSER) et dans Node (validation). */
(function (racine) {
  'use strict';

  function nettoyer(lignes) {
    while (lignes.length && lignes[0].trim() === '') lignes.shift();
    while (lignes.length && lignes[lignes.length - 1].trim() === '') lignes.pop();
    return lignes.join('\n');
  }

  function lireModule(texte) {
    const mod = { id: '', titre: '', partie: '', resume: '', fichiers: {}, lecons: [] };
    let lecon = null, exo = null, cible = null, tampon = [];

    const fermer = () => {
      if (!cible) { tampon = []; return; }
      const val = nettoyer(tampon);
      tampon = [];
      const c = cible; cible = null;
      if (c.kind === 'entete') {
        val.split('\n').forEach(l => {
          const m = l.match(/^(\w+)\s*:\s*(.*)$/);
          if (m) mod[m[1]] = m[2].trim();
        });
      } else if (c.kind === 'lecon') lecon.contenu = val;
      else if (c.kind === 'exercice') exo.enonce = val;
      else if (c.kind === 'depart') exo.depart = val;
      else if (c.kind === 'tests') exo.tests = val;
      else if (c.kind === 'solution') exo.solution = val;
      else if (c.kind === 'indice') exo.indices.push(val);
      else if (c.kind === 'entrees') exo.entrees = val === '' ? [] : val.split('\n');
      else if (c.kind === 'fichier') {
        if (exo) exo.fichiers[c.nom] = val + '\n';
        else mod.fichiers[c.nom] = val + '\n';
      }
    };

    texte.replace(/\r\n/g, '\n').split('\n').forEach(ligne => {
      const m = ligne.match(/^@@(\w+)\s*(.*)$/);
      if (!m) { tampon.push(ligne); return; }
      fermer();
      const mot = m[1], reste = m[2].trim();
      if (mot === 'module') { mod.id = reste; cible = { kind: 'entete' }; }
      else if (mot === 'lecon') {
        const [id, ...t] = reste.split(/\s+/);
        lecon = { id, titre: t.join(' '), contenu: '', exercices: [] };
        mod.lecons.push(lecon); exo = null; cible = { kind: 'lecon' };
      } else if (mot === 'exercice') {
        const [id, ...t] = reste.split(/\s+/);
        exo = { id, titre: t.join(' '), enonce: '', depart: '', tests: '', solution: '',
                indices: [], entrees: null, fichiers: {} };
        lecon.exercices.push(exo); cible = { kind: 'exercice' };
      } else if (mot === 'fichier') cible = { kind: 'fichier', nom: reste };
      else if (mot === 'fin') { exo = null; cible = null; }
      else cible = { kind: mot };
    });
    fermer();
    return mod;
  }

  /* ---------- Markdown ---------- */
  const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  function enLigne(s) {
    const codes = [];
    s = s.replace(/`([^`]+)`/g, (_, c) => { codes.push(c); return '\u0000' + (codes.length - 1) + '\u0000'; });
    s = esc(s);
    s = s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
         .replace(/(^|[^\w*])\*(?!\s)(.+?)\*(?!\w)/g, '$1<em>$2</em>')
         .replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, '<a href="$2">$1</a>');
    return s.replace(/\u0000(\d+)\u0000/g, (_, i) => '<code>' + esc(codes[+i]) + '</code>');
  }

  function rendre(md) {
    const L = (md || '').split('\n');
    const out = [];
    let i = 0;
    const estSpecial = l => /^(```|#{2,4} |> ?|[-*] |\d+\. |\|)/.test(l);
    while (i < L.length) {
      let l = L[i];
      if (l.trim() === '') { i++; continue; }
      let m;
      if ((m = l.match(/^```\s*(\w*)/))) {
        const lang = m[1] || 'text'; const bloc = []; i++;
        while (i < L.length && !/^```/.test(L[i])) bloc.push(L[i++]);
        i++;
        const code = bloc.join('\n');
        if (lang === 'python') out.push('<div class="exemple" data-code="' + esc(code) + '"></div>');
        else out.push('<pre class="statique' + (lang === 'sortie' ? ' sortie-ex' : '') + '">' + esc(code) + '</pre>');
        continue;
      }
      if ((m = l.match(/^(#{2,4}) (.*)$/))) {
        const n = m[1].length; out.push(`<h${n}>${enLigne(m[2])}</h${n}>`); i++; continue;
      }
      if (/^> ?/.test(l)) {
        const bloc = [];
        while (i < L.length && /^> ?/.test(L[i])) bloc.push(L[i++].replace(/^> ?/, ''));
        let cls = 'note';
        if (/^!\s*/.test(bloc[0])) { cls = 'note attention'; bloc[0] = bloc[0].replace(/^!\s*/, ''); }
        out.push(`<div class="${cls}">` + rendre(bloc.join('\n')) + '</div>');
        continue;
      }
      if (/^[-*] /.test(l) || /^\d+\. /.test(l)) {
        const ord = /^\d+\. /.test(l);
        const items = [];
        while (i < L.length) {
          const cur = L[i];
          if (ord ? /^\d+\. /.test(cur) : /^[-*] /.test(cur)) items.push(cur.replace(/^([-*]|\d+\.) /, ''));
          else if (items.length && /^ {2,}\S/.test(cur)) items[items.length - 1] += ' ' + cur.trim();
          else break;
          i++;
        }
        const t = ord ? 'ol' : 'ul';
        out.push(`<${t}>` + items.map(x => '<li>' + enLigne(x) + '</li>').join('') + `</${t}>`);
        continue;
      }
      if (/^\|/.test(l)) {
        const rows = [];
        while (i < L.length && /^\|/.test(L[i])) rows.push(L[i++]);
        const cells = r => r.replace(/\\\|/g, '\u0001').replace(/^\||\|\s*$/g, '').split('|')
          .map(c => c.trim().replace(/\u0001/g, '|'));
        let h = '<table><thead><tr>' + cells(rows[0]).map(c => '<th>' + enLigne(c) + '</th>').join('') + '</tr></thead><tbody>';
        rows.slice(/^\|[\s:-]+\|/.test(rows[1] || '') ? 2 : 1).forEach(r => {
          h += '<tr>' + cells(r).map(c => '<td>' + enLigne(c) + '</td>').join('') + '</tr>';
        });
        out.push(h + '</tbody></table>');
        continue;
      }
      const para = [];
      while (i < L.length && L[i].trim() !== '' && !estSpecial(L[i])) para.push(L[i++]);
      if (!para.length) { para.push(L[i++]); }
      out.push('<p>' + enLigne(para.join(' ')) + '</p>');
    }
    return out.join('\n');
  }

  const api = { lireModule, rendre, esc };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else racine.PS_PARSER = api;
})(typeof window !== 'undefined' ? window : this);
