# Moteur d'exécution et de correction de PyStage.
# Chargé dans Pyodide (navigateur) ; utilisable aussi avec CPython pour valider le contenu.
import sys, io, os, json, traceback, builtins, shutil

FICHIER_ELEVE = "<votre code>"
LIMITE_SORTIE = 200_000
DOSSIER = "/home/pyodide/travail" if sys.platform == "emscripten" else None


class EchecTest(Exception):
    pass


class SortieTropLongue(Exception):
    pass


class _Sortie(io.StringIO):
    def write(self, s):
        if self.tell() + len(s) > LIMITE_SORTIE:
            raise SortieTropLongue(
                "La sortie dépasse 200 000 caractères. Une boucle affiche probablement sans fin.")
        return super().write(s)


EXPLICATIONS = {
    "SyntaxError": "Erreur de syntaxe : Python ne comprend pas la ligne. Cherchez un deux-points manquant, une parenthèse ou un guillemet non fermé.",
    "IndentationError": "Erreur d'indentation : les blocs (après if, for, def...) doivent être décalés de façon cohérente, en général de 4 espaces.",
    "TabError": "Mélange de tabulations et d'espaces dans l'indentation.",
    "NameError": "Nom inconnu : une variable ou une fonction est utilisée avant d'avoir été définie, ou son nom est mal orthographié.",
    "TypeError": "Erreur de type : une opération est appliquée à une valeur du mauvais type (par exemple additionner un texte et un nombre), ou une fonction reçoit un mauvais nombre d'arguments.",
    "ValueError": "Valeur invalide : le type est correct mais la valeur ne convient pas (par exemple int(\"abc\")).",
    "IndexError": "Indice hors limites : vous accédez à une position qui n'existe pas dans la séquence.",
    "KeyError": "Clé absente : cette clé n'existe pas dans le dictionnaire.",
    "ZeroDivisionError": "Division par zéro.",
    "AttributeError": "Attribut inconnu : cet objet ne possède pas la méthode ou l'attribut demandé.",
    "FileNotFoundError": "Fichier introuvable : vérifiez le nom du fichier.",
    "RecursionError": "Récursion trop profonde : la fonction s'appelle elle-même sans condition d'arrêt atteinte.",
    "EOFError": "input() a été appelé alors qu'aucune entrée n'était disponible. Renseignez la zone « Entrées » (une valeur par ligne).",
    "UnboundLocalError": "Variable locale utilisée avant affectation : dans une fonction, une variable affectée est considérée comme locale.",
    "ModuleNotFoundError": "Module introuvable dans cet environnement.",
    "SortieTropLongue": "Sortie trop longue.",
    "AssertionError": "Une instruction assert a échoué.",
}


def _formater_erreur(e):
    nom = type(e).__name__
    ligne = None
    if isinstance(e, SyntaxError) and e.filename == FICHIER_ELEVE:
        ligne = e.lineno
    else:
        for f in traceback.extract_tb(e.__traceback__):
            if f.filename == FICHIER_ELEVE:
                ligne = f.lineno
    msg = str(e) if not isinstance(e, SyntaxError) else (e.msg or "")
    return {"type": nom, "message": msg, "ligne": ligne, "explication": EXPLICATIONS.get(nom, "")}


def _preparer_fichiers(fichiers):
    if DOSSIER is None:
        return
    os.chdir("/")
    if os.path.isdir(DOSSIER):
        shutil.rmtree(DOSSIER)
    os.makedirs(DOSSIER)
    os.chdir(DOSSIER)
    for nom, contenu in (fichiers or {}).items():
        chemin = os.path.join(DOSSIER, nom)
        os.makedirs(os.path.dirname(chemin), exist_ok=True)
        if contenu.startswith("base64:"):
            import base64
            with open(chemin, "wb") as f:
                f.write(base64.b64decode(contenu[7:]))
        else:
            with open(chemin, "w", encoding="utf-8") as f:
                f.write(contenu)


def _executer(code, entrees, echo):
    sortie = _Sortie()
    file = [str(x) for x in entrees]

    def _input(invite=""):
        if echo:
            sortie.write(str(invite))
        if not file:
            raise EOFError("plus aucune entrée disponible")
        v = file.pop(0)
        if echo:
            sortie.write(v + "\n")
        return v

    ns = {"__name__": "__main__", "__builtins__": builtins, "input": _input}
    anciens = sys.stdout, sys.stderr
    sys.stdout = sys.stderr = sortie
    erreur = None
    try:
        exec(compile(code, FICHIER_ELEVE, "exec"), ns)
    except SystemExit:
        pass
    except BaseException as e:  # noqa
        erreur = e
    finally:
        sys.stdout, sys.stderr = anciens
    return ns, sortie.getvalue(), erreur


def executer_json(charge_json):
    p = json.loads(charge_json)
    code = p.get("code", "")
    fichiers = p.get("fichiers") or {}
    _preparer_fichiers(fichiers)
    ns, sortie, err = _executer(code, p.get("entrees") or [], echo=True)
    res = {"sortie": sortie, "erreur": _formater_erreur(err) if err else None, "tests": None}
    tests = p.get("tests")
    if not tests:
        return json.dumps(res)
    if err:
        res["tests"] = {"ok": False, "n": 0,
                        "message": "Le programme s'arrête sur une erreur : corrigez-la avant la vérification."}
        return json.dumps(res)

    compteur = [0]

    def verifier(condition, message="Vérification échouée."):
        if not condition:
            raise EchecTest(message)
        compteur[0] += 1

    def egal(obtenu, attendu, message="Résultat incorrect."):
        if obtenu != attendu:
            raise EchecTest(f"{message}\n    obtenu  : {obtenu!r}\n    attendu : {attendu!r}")
        compteur[0] += 1

    def fonction(nom):
        f = ns.get(nom)
        if not callable(f):
            raise EchecTest(f"La fonction {nom}() n'est pas définie.")
        return f

    def variable(nom):
        if nom not in ns:
            raise EchecTest(f"La variable {nom} n'existe pas.")
        return ns[nom]

    def executer(entrees=()):
        _preparer_fichiers(fichiers)
        _, s, e = _executer(code, list(entrees), echo=False)
        if e:
            raise EchecTest(f"Avec les entrées {list(entrees)!r}, le programme lève {type(e).__name__} : {e}")
        return s

    def capturer(f, *args, **kwargs):
        buf = _Sortie()
        anciens = sys.stdout
        sys.stdout = buf
        try:
            r = f(*args, **kwargs)
        finally:
            sys.stdout = anciens
        return r, buf.getvalue()

    def lignes(texte):
        return [l.rstrip() for l in texte.strip().splitlines()]

    tns = {
        "verifier": verifier, "egal": egal, "fonction": fonction, "variable": variable,
        "executer": executer, "capturer": capturer, "lignes": lignes,
        "sortie": sortie, "source": code, "ns": ns, "EchecTest": EchecTest,
    }
    try:
        exec(compile(tests, "<tests>", "exec"), tns)
        res["tests"] = {"ok": True, "n": compteur[0], "message": ""}
    except EchecTest as e:
        res["tests"] = {"ok": False, "n": compteur[0], "message": str(e)}
    except BaseException as e:  # noqa
        info = _formater_erreur(e)
        where = f" (ligne {info['ligne']} de votre code)" if info["ligne"] else ""
        res["tests"] = {"ok": False, "n": compteur[0],
                        "message": f"Pendant la vérification, votre code a levé {info['type']} : {info['message']}{where}"}
    return json.dumps(res)
