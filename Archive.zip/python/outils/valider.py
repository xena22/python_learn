"""Vérifie que chaque solution passe ses tests, que chaque code de départ échoue,
et que les exemples du cours s'exécutent sans erreur.
Usage : node valider.js | python3 valider.py"""
import sys, json, tempfile, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../site/js'))
import harness
harness.DOSSIER = tempfile.mkdtemp(prefix='pystage-')
items = json.load(sys.stdin)
erreurs = 0; n = 0
for it in items:
    if it.get('exemple'):
        r = json.loads(harness.executer_json(json.dumps({'code': it['code'], 'fichiers': it['fichiers']})))
        if r['erreur'] and 'erreur volontaire' not in it['code'].lower():
            print('EXEMPLE KO', it['k'], r['erreur']); erreurs += 1
        continue
    n += 1
    base = {'tests': it['tests'], 'entrees': it['entrees'], 'fichiers': it['fichiers']}
    r = json.loads(harness.executer_json(json.dumps(dict(base, code=it['solution']))))
    if not (r['tests'] and r['tests']['ok']):
        print('SOLUTION KO', it['k'], r['erreur'], r['tests']); erreurs += 1
    r = json.loads(harness.executer_json(json.dumps(dict(base, code=it['depart']))))
    if r['tests'] and r['tests']['ok']:
        print('DEPART PASSE DEJA', it['k']); erreurs += 1
print(f'{n} exercices, {erreurs} problème(s)')
sys.exit(1 if erreurs else 0)
