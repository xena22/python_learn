// Exporte tous les exercices au format JSON pour valider.py
const fs = require('fs'), path = require('path');
const P = require('../site/js/parser.js');
const dir = path.join(__dirname, '../site/content');
const som = JSON.parse(fs.readFileSync(path.join(dir, 'sommaire.json'), 'utf8'));
const out = [];
for (const f of som.modules) {
  const m = P.lireModule(fs.readFileSync(path.join(dir, f), 'utf8'));
  if (!m.id) console.error('Module sans id :', f);
  for (const l of m.lecons) {
    // exemples du cours
    const re = /```python\n([\s\S]*?)\n```/g; let x, n = 0;
    while ((x = re.exec(l.contenu))) out.push({ k: `${m.id}/${l.id}/exemple${++n}`, exemple: true, code: x[1], fichiers: m.fichiers });
    for (const e of l.exercices) {
      if (!e.tests) console.error('Sans tests :', m.id, l.id, e.id);
      if (!e.solution) console.error('Sans solution :', m.id, l.id, e.id);
      out.push({ k: `${m.id}/${l.id}/${e.id}`, depart: e.depart, solution: e.solution, tests: e.tests,
        entrees: e.entrees || [], fichiers: Object.assign({}, m.fichiers, e.fichiers) });
    }
  }
}
process.stdout.write(JSON.stringify(out));
