# PyStage — apprendre Python jusqu'à la cybersécurité

Seconde plateforme du stage : un parcours Python progressif, de `print()` à l'analyse
d'une intrusion. Le code s'exécute dans le navigateur (Pyodide, Python 3.12 compilé en
WebAssembly) : aucune installation côté élève, aucun envoi de code vers un serveur.

| | |
|---|---|
| Modules | 20 (4 parties) |
| Leçons | 63 |
| Exercices corrigés automatiquement | 168 |
| Accès | `http://IP-DE-LA-VM:8089` |

## Contenu

**Partie 1 — Fondamentaux** : premiers pas, chaînes, entrées et conditions, boucles,
listes et tuples, dictionnaires et ensembles, fonctions.

**Partie 2 — Intermédiaire** : compréhensions et écritures idiomatiques, exceptions,
fichiers/CSV/JSON, bibliothèque standard, expressions régulières, programmation objet.

**Partie 3 — Sécurité** : bits/octets/encodages (Base64 à la main, XOR, drapeaux TCP,
permissions Unix), cryptographie classique (César, analyse fréquentielle, khi-deux,
Vigenère, XOR, réutilisation de clé), hachage et mots de passe (attaques par
dictionnaire, sel, règles de transformation, `secrets`, HMAC, PBKDF2 à implémenter),
analyse de journaux (force brute SSH, scanners web, SQLi/XSS, webshell, chronologie et
rapport d'incident), réseau (CIDR, dissection d'en-têtes IPv4/TCP, flux, tunnel DNS),
forensic (signatures, `strings`, données cachées après IEND, métadonnées de fichiers).

**Partie 4 — Défi final** : enquête en cinq épreuves enchaînées avec drapeaux
`FLAG{...}`, sans guidage.

Les modules 17 à 20 portent sur le même scénario d'intrusion : les résultats de l'un se
retrouvent dans les suivants.

## Fonctionnement pour l'élève

- **Exécuter** (Ctrl+Entrée) lance le code ; **Vérifier** (Ctrl+Maj+Entrée) lance les tests.
- Les indices se débloquent un par un ; la solution n'est accessible qu'après 3 vérifications,
  et l'exercice est alors marqué « vu avec solution » (visible dans la progression).
- Le code et la progression sont enregistrés dans le navigateur (localStorage).
- Page **Progression** : export JSON (statuts + code écrit pour chaque exercice), import,
  réinitialisation. Utile pour relire son travail ou changer de poste.
- Une boucle infinie est interrompue au bout de 10 secondes (le Python tourne dans un
  Web Worker qui est redémarré).

## Déploiement

Le service `pystage` est déclaré dans le `docker-compose.yml` à la racine du projet,
à côté de CyberStage :

```bash
cd stagiaire3eme
docker compose up -d            # lance les deux plateformes
docker compose up -d pystage    # uniquement celle-ci
```

Tout est servi localement (Pyodide et CodeMirror sont dans `site/vendor/`) : la
plateforme fonctionne sans accès Internet. Seule la police Inter est chargée depuis
Google Fonts, avec repli automatique sur la police système.

## Structure

```
python/
├── nginx.conf                 # config du conteneur (types MIME wasm, cache)
├── outils/
│   ├── valider.js / valider.py  # vérification automatique du contenu
│   └── generer_journaux.py      # régénère les journaux du module 17
└── site/
    ├── index.html
    ├── css/style.css
    ├── js/
    │   ├── app.js         # interface, routeur, progression
    │   ├── parser.js      # lecture des fichiers de contenu + Markdown
    │   ├── runner.js      # pilotage du worker (délai, redémarrage)
    │   ├── worker.js      # charge Pyodide
    │   └── harness.py     # exécution du code élève et des tests
    ├── content/
    │   ├── sommaire.json  # ordre des modules
    │   ├── memo.txt       # aide-mémoire
    │   └── mXX-*.txt      # un fichier par module
    └── vendor/            # Pyodide 0.26.4, CodeMirror 5.65
```

## Modifier ou ajouter du contenu

Chaque module est un fichier texte. Les sections commencent par `@@` en début de ligne :

```text
@@module m21
titre: Mon module
partie: Partie 3 — Sécurité
resume: Une phrase.

@@fichier donnees.txt          (fichier disponible pour tout le module)
contenu...

@@lecon l1 Titre de la leçon
Texte en Markdown simplifié : ## titres, listes, tableaux, `code`, **gras**,
> note, >! avertissement. Un bloc ```python devient un exemple exécutable.

@@exercice e1 Titre de l'exercice
Énoncé en Markdown.
@@depart
code de départ
@@entrees
valeurs pour input(), une par ligne (facultatif ; affiche la zone de saisie)
@@tests
egal(fonction("f")(2), 4)
@@indice
Premier indice.
@@indice
Second indice.
@@solution
def f(x):
    return x * 2
```

Fonctions disponibles dans `@@tests` : `egal(obtenu, attendu, message)`,
`verifier(condition, message)`, `fonction(nom)`, `variable(nom)`,
`executer(entrees)` (relance le programme avec d'autres saisies et renvoie sa sortie),
`capturer(f, *args)`, `lignes(texte)`, ainsi que `sortie` (ce qui a été affiché) et
`source` (le code de l'élève).

Ajouter le fichier dans `content/sommaire.json`, puis vérifier :

```bash
cd python
node outils/valider.js | python3 outils/valider.py
```

Le script contrôle que chaque solution passe ses tests, que chaque code de départ
échoue, et que les exemples du cours s'exécutent sans erreur (sauf ceux qui contiennent
le commentaire « erreur volontaire »). Les modifications sont visibles en rafraîchissant
la page, sans redémarrer le conteneur.
