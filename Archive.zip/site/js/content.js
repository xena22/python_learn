/* ============================================================
   CONTENU PÉDAGOGIQUE — Plateforme Cybersécurité (stage 3ème)
   Version longue (programme ~4 jours).
   Chaque module = { id, titre, icone, couleur, resume, duree,
                     lecons[], qcm[], labs[] }
   Rédaction simple (niveau 3ème) mais complète.
   ============================================================ */

const MODULES = [

/* ========================================================== */
/* 0. INTRODUCTION & GOUVERNANCE                              */
/* ========================================================== */
{
  id: "intro",
  titre: "Introduction & Gouvernance",
  icone: "🛡️",
  couleur: "#22A96A",
  resume: "Comprendre la cybersécurité, les menaces, les règles et les métiers.",
  duree: "1 h 15",
  lecons: [
    {
      titre: "C'est quoi la cybersécurité ?",
      html: `
        <p>La <strong>cybersécurité</strong>, c'est l'ensemble des moyens mis en place pour <strong>protéger</strong>
        les ordinateurs, les téléphones, les réseaux et surtout les <strong>données</strong> (les informations)
        contre les personnes malveillantes.</p>
        <p>Imagine ton collège : il y a des portes, des serrures, un gardien, des règles d'entrée et de sortie.
        En informatique, c'est exactement pareil ! On protège des « bâtiments numériques » avec des
        « serrures numériques », des « gardiens numériques » et des règles.</p>
        <div class="callout callout-info">
          <strong>Le saviez-vous ?</strong> Chaque jour, des millions d'attaques informatiques ont lieu dans le monde.
          La plupart sont <strong>automatiques</strong> : ce sont des programmes (des robots) qui cherchent des failles
          tout seuls, 24 heures sur 24, sur des millions de machines en même temps.
        </div>
        <h4>Pourquoi c'est devenu si important ?</h4>
        <p>Aujourd'hui, <strong>presque tout est connecté</strong> : les banques, les hôpitaux, les écoles, les voitures,
        les objets de la maison... Si quelqu'un prend le contrôle de ces systèmes, les conséquences peuvent être graves :
        un hôpital bloqué ne peut plus soigner, une entreprise piratée peut perdre tous ses clients, une personne
        peut se faire voler son argent ou son identité.</p>
        <h4>Qui attaque, et pourquoi ?</h4>
        <ul>
          <li>💰 <strong>Pour l'argent</strong> : voler des numéros de carte bancaire, réclamer une rançon, revendre des données.</li>
          <li>🕵️ <strong>Pour espionner</strong> : voler des secrets d'entreprises, de gouvernements ou d'armées.</li>
          <li>😈 <strong>Pour nuire ou se venger</strong> : saboter, détruire, humilier.</li>
          <li>🎭 <strong>Pour militer</strong> : les « hacktivistes » attaquent pour défendre une cause.</li>
          <li>✅ <strong>Pour protéger</strong> : ce sont les « gentils » (comme nous !) qui testent les systèmes
          pour les rendre plus solides et défendre les autres.</li>
        </ul>
        <div class="callout callout-tip">
          <strong>À retenir :</strong> la cybersécurité n'est pas qu'une affaire d'informaticiens. C'est l'affaire
          de <strong>tout le monde</strong>, car nous utilisons tous des appareils connectés.
        </div>`
    },
    {
      titre: "Un peu d'histoire : des premiers virus à aujourd'hui",
      html: `
        <p>Comprendre d'où ça vient aide à comprendre où on va. Voici les grandes étapes, racontées simplement.</p>
        <table class="table">
          <tr><th>Époque</th><th>Ce qui s'est passé</th></tr>
          <tr><td><strong>Années 1970</strong></td><td>« Creeper », considéré comme le premier programme qui se déplace tout seul d'ordinateur en ordinateur. Il affichait juste : « Attrape-moi si tu peux ! ».</td></tr>
          <tr><td><strong>Années 1980-90</strong></td><td>Arrivée des <strong>virus</strong> qui se propagent par disquettes, puis par internet. On invente les premiers <strong>antivirus</strong>.</td></tr>
          <tr><td><strong>Années 2000</strong></td><td>Internet se généralise. Les attaques deviennent <strong>criminelles</strong> : vol de cartes bancaires, arnaques par e-mail (phishing).</td></tr>
          <tr><td><strong>Années 2010</strong></td><td>Les <strong>rançongiciels</strong> (ransomware) explosent : on bloque tes fichiers et on réclame de l'argent. Des États s'attaquent entre eux (cyberguerre).</td></tr>
          <tr><td><strong>Aujourd'hui</strong></td><td>Tout est connecté (objets, voitures, usines). L'<strong>intelligence artificielle</strong> est utilisée par les attaquants... et par les défenseurs !</td></tr>
        </table>
        <div class="callout callout-info">
          Le mot « hacker » signifiait au départ « bidouilleur passionné », quelqu'un de curieux qui aime comprendre
          comment les choses marchent. Ce n'était pas un gros mot ! On distingue aujourd'hui les gentils des méchants
          (tu verras ça dans le parcours Pentest).
        </div>`
    },
    {
      titre: "Les 3 piliers : Confidentialité, Intégrité, Disponibilité",
      html: `
        <p>En sécurité, on protège toujours 3 choses. On appelle ça le triangle <strong>CID</strong>
        (en anglais « CIA »). C'est <strong>LA base</strong> à retenir toute la semaine : tout tourne autour de ces 3 mots !</p>
        <div class="grid-cards">
          <div class="mini-card"><div class="mini-icon">🔒</div><h4>Confidentialité</h4>
            <p>Seules les personnes autorisées peuvent voir l'information.</p></div>
          <div class="mini-card"><div class="mini-icon">✔️</div><h4>Intégrité</h4>
            <p>L'information n'est pas modifiée en douce.</p></div>
          <div class="mini-card"><div class="mini-icon">⚡</div><h4>Disponibilité</h4>
            <p>L'information est accessible quand on en a besoin.</p></div>
        </div>
        <h4>Des exemples concrets</h4>
        <table class="table">
          <tr><th>Situation</th><th>Pilier concerné</th></tr>
          <tr><td>Quelqu'un lit tes messages privés sans ta permission</td><td>🔒 Confidentialité (atteinte)</td></tr>
          <tr><td>Ta note de 15 est transformée en 5 dans le logiciel de l'école</td><td>✔️ Intégrité (atteinte)</td></tr>
          <tr><td>Le site du collège est inaccessible le jour des inscriptions</td><td>⚡ Disponibilité (atteinte)</td></tr>
          <tr><td>Un médecin accède au dossier de son patient quand il faut</td><td>⚡ Disponibilité (respectée)</td></tr>
        </table>
        <div class="callout callout-tip">
          <strong>Astuce mémoire :</strong> un coffre-fort (confidentialité), un sceau de cire intact (intégrité),
          et une banque ouverte aux heures d'ouverture (disponibilité). Le métier du cyber, c'est de garder
          ces 3 choses en équilibre en permanence.
        </div>
        <p>Parfois, on ajoute 2 piliers : la <strong>traçabilité</strong> (savoir qui a fait quoi) et la
        <strong>authentification</strong> (prouver qu'on est bien la bonne personne). Tu les retrouveras partout.</p>`
    },
    {
      titre: "Le zoo des menaces : virus, ransomware, phishing...",
      html: `
        <p>On regroupe les programmes malveillants sous le mot <strong>« malware »</strong>
        (de l'anglais <em>malicious software</em>, logiciel méchant). Voici les plus connus :</p>
        <table class="table">
          <tr><th>Menace</th><th>Ce qu'elle fait</th></tr>
          <tr><td>🦠 <strong>Virus</strong></td><td>Se cache dans un fichier et se copie pour se propager.</td></tr>
          <tr><td>🐛 <strong>Ver (worm)</strong></td><td>Se propage tout seul sur le réseau, sans qu'on clique sur rien.</td></tr>
          <tr><td>🐴 <strong>Cheval de Troie</strong></td><td>Se déguise en logiciel normal (un jeu, une appli) mais cache un piège.</td></tr>
          <tr><td>💰 <strong>Rançongiciel (ransomware)</strong></td><td>Verrouille tes fichiers et réclame de l'argent pour les débloquer.</td></tr>
          <tr><td>👁️ <strong>Logiciel espion (spyware)</strong></td><td>Surveille ce que tu fais (mots de passe, frappes au clavier).</td></tr>
          <tr><td>🎣 <strong>Phishing (hameçonnage)</strong></td><td>Un faux message pour te piéger et voler tes identifiants.</td></tr>
          <tr><td>🌊 <strong>DDoS</strong></td><td>Inonde un site de connexions pour le faire tomber (attaque la disponibilité).</td></tr>
        </table>
        <div class="callout callout-warning">
          <strong>Le ransomware, l'ennemi n°1 des entreprises.</strong> Un matin, tous les fichiers de l'entreprise
          sont illisibles, et un message réclame une rançon (souvent en cryptomonnaie). C'est pour ça que les
          <strong>sauvegardes</strong> sont si importantes : avec une bonne sauvegarde, on peut tout restaurer sans payer.
        </div>
        <h4>Le facteur humain</h4>
        <p>La plupart des attaques réussissent à cause d'une <strong>erreur humaine</strong> : un clic sur un mauvais lien,
        un mot de passe trop simple, une clé USB inconnue branchée par curiosité. La meilleure protection, c'est
        <strong>la vigilance</strong> de chacun.</p>`
    },
    {
      titre: "La gouvernance : les règles et les responsabilités",
      html: `
        <p>La <strong>gouvernance</strong>, ce sont les <strong>règles et les responsabilités</strong>.
        Qui a le droit de faire quoi ? Qui décide ? Que faire en cas de problème ? Ces règles sont écrites dans des
        documents officiels appelés <strong>politiques de sécurité</strong> (en anglais « policies »).</p>
        <p>Sans gouvernance, la sécurité, c'est comme un sport sans arbitre ni règles : le chaos. La gouvernance
        donne un cadre clair à tout le monde.</p>
        <h4>Quelques documents importants</h4>
        <ul>
          <li>📜 <strong>La PSSI</strong> (Politique de Sécurité des Systèmes d'Information) : le grand règlement de la maison.</li>
          <li>📋 <strong>La charte informatique</strong> : les règles pour les employés (que faire, que ne pas faire).</li>
          <li>🚨 <strong>Le plan de réponse à incident</strong> : la marche à suivre quand ça tourne mal.</li>
        </ul>
        <h4>La gestion du risque</h4>
        <p>On ne peut pas tout protéger parfaitement (ça coûterait trop cher). Alors on évalue les <strong>risques</strong> :
        un risque, c'est la combinaison d'une <strong>menace</strong> (ce qui peut arriver) et de son <strong>impact</strong>
        (la gravité). On protège en priorité ce qui est le plus important et le plus menacé.</p>
        <div class="callout callout-info">
          <strong>Image simple :</strong> tu ne mets pas un coffre-fort blindé pour ranger tes crayons, mais tu en mets
          un pour tes bijoux. En entreprise, c'est pareil : on protège le plus fort ce qui a le plus de valeur.
        </div>`
    },
    {
      titre: "Le RGPD et la protection de tes données",
      html: `
        <p>Le <strong>RGPD</strong> (Règlement Général sur la Protection des Données) est une <strong>loi européenne</strong>
        de 2018 qui protège <strong>tes données personnelles</strong> : ton nom, ta photo, ton adresse, ta date de
        naissance, ta localisation, tes goûts... Tout ce qui permet de t'identifier.</p>
        <h4>Ce que le RGPD impose aux entreprises</h4>
        <ul>
          <li>🙋 <strong>Te demander ton accord</strong> avant de collecter tes données (le fameux « j'accepte les cookies »).</li>
          <li>🎯 <strong>N'utiliser tes données que pour ce qui est prévu</strong>, pas pour autre chose en douce.</li>
          <li>🔒 <strong>Protéger tes données</strong> correctement (sécurité).</li>
          <li>🗑️ <strong>Les effacer</strong> si tu le demandes (« droit à l'oubli »).</li>
          <li>⏱️ <strong>Prévenir vite</strong> en cas de fuite de données.</li>
        </ul>
        <h4>Tes droits</h4>
        <p>Grâce au RGPD, tu peux demander à un site : « Quelles informations avez-vous sur moi ? », « Corrigez cette
        erreur », ou « Supprimez tout ». En France, c'est la <strong>CNIL</strong> qui veille au respect de cette loi
        et peut infliger de grosses amendes aux entreprises qui trichent.</p>
        <div class="callout callout-warning">
          <strong>Et toi ?</strong> Avant de publier une photo de quelqu'un, il faut son accord. Les données des autres
          aussi sont protégées. Respecter la vie privée des autres, c'est la base.
        </div>`
    },
    {
      titre: "Les métiers de la cybersécurité",
      html: `
        <p>La cybersécurité, c'est une multitude de métiers passionnants ! On les regroupe souvent en deux « équipes »,
        comme au sport :</p>
        <div class="grid-cards">
          <div class="mini-card"><div class="mini-icon">🔴</div><h4>Red Team</h4>
            <p>Les attaquants « gentils ». Ils testent les défenses en jouant le rôle des pirates.</p></div>
          <div class="mini-card"><div class="mini-icon">🔵</div><h4>Blue Team</h4>
            <p>Les défenseurs. Ils surveillent, détectent et bloquent les attaques.</p></div>
        </div>
        <p>Voici les métiers que tu vas découvrir cette semaine :</p>
        <table class="table">
          <tr><th>Métier</th><th>Équipe</th><th>Son rôle en une phrase</th></tr>
          <tr><td>🔍 <strong>Analyste SOC</strong></td><td>🔵</td><td>Surveille les écrans et détecte les attaques en direct.</td></tr>
          <tr><td>⚔️ <strong>Pentester</strong></td><td>🔴</td><td>Joue au « gentil pirate » pour trouver les failles.</td></tr>
          <tr><td>🔬 <strong>Analyste Forensic</strong></td><td>🔵</td><td>Mène l'enquête après une attaque.</td></tr>
          <tr><td>🌐 <strong>Analyste OSINT</strong></td><td>🔴🔵</td><td>Trouve des informations publiques utiles.</td></tr>
          <tr><td>🏗️ <strong>Architecte cyber</strong></td><td>🔵</td><td>Conçoit des systèmes solides et bien défendus.</td></tr>
          <tr><td>📋 <strong>RSSI</strong></td><td>👔</td><td>Le chef de la sécurité : décide des règles et gère les risques.</td></tr>
        </table>
        <div class="callout callout-tip">
          <strong>Bonne nouvelle :</strong> pas besoin d'être un génie des maths ! Il faut surtout être
          <strong>curieux</strong>, <strong>logique</strong>, <strong>rigoureux</strong> et aimer
          <strong>résoudre des énigmes</strong>. Et il manque énormément de professionnels : c'est un domaine
          qui recrute beaucoup, avec de belles carrières.
        </div>`
    }
  ],
  qcm: [
    { q: "Que protège la cybersécurité avant tout ?", choix: ["Uniquement les jeux vidéo", "Les données et les systèmes informatiques", "Seulement les téléphones", "Les voitures anciennes"], bonne: 1,
      explication: "On protège les systèmes ET surtout les données (les informations)." },
    { q: "Dans le triangle CID, que signifie le 'C' ?", choix: ["Copie", "Confidentialité", "Connexion", "Caméra"], bonne: 1,
      explication: "C = Confidentialité : seules les personnes autorisées voient l'information." },
    { q: "Ta note de 15 est changée en 5 dans la base de l'école. Quel pilier est atteint ?", choix: ["La disponibilité", "La confidentialité", "L'intégrité", "Aucun"], bonne: 2,
      explication: "L'information a été modifiée : c'est l'intégrité qui est touchée." },
    { q: "Un rançongiciel (ransomware)...", choix: ["Accélère l'ordinateur", "Verrouille tes fichiers et réclame de l'argent", "Nettoie les virus", "Range tes photos"], bonne: 1,
      explication: "Le ransomware chiffre tes fichiers et demande une rançon pour les rendre." },
    { q: "Quelle protection permet de restaurer ses fichiers après un ransomware ?", choix: ["Changer d'écran", "Une bonne sauvegarde", "Éteindre le wifi", "Acheter un nouveau PC"], bonne: 1,
      explication: "Avec une sauvegarde saine, on restaure sans payer la rançon." },
    { q: "À quoi sert le RGPD ?", choix: ["À vendre des données", "À protéger les données personnelles des citoyens", "À créer des virus", "À ralentir internet"], bonne: 1,
      explication: "Le RGPD est la loi européenne qui protège tes données personnelles." },
    { q: "En France, quelle autorité veille au respect du RGPD ?", choix: ["La CNIL", "La SNCF", "La CAF", "La FIFA"], bonne: 0,
      explication: "La CNIL contrôle l'usage des données personnelles en France." },
    { q: "La 'Blue Team', c'est l'équipe qui...", choix: ["Attaque pour tester", "Défend, surveille et bloque", "Vend des ordinateurs", "Fait le ménage"], bonne: 1,
      explication: "La Blue Team défend ; la Red Team attaque pour tester." }
  ],
  labs: []
},

/* ========================================================== */
/* 1. OSINT                                                   */
/* ========================================================== */
{
  id: "osint",
  titre: "OSINT — L'enquête en sources ouvertes",
  icone: "🌐",
  couleur: "#0ea5e9",
  resume: "Trouver et vérifier des informations publiques comme un détective du web.",
  duree: "1 h 10",
  lecons: [
    {
      titre: "L'OSINT, c'est quoi ?",
      html: `
        <p><strong>OSINT</strong> veut dire <em>« Open Source Intelligence »</em>, c'est-à-dire
        <strong>le renseignement à partir de sources ouvertes</strong>. En clair : trouver des informations
        <strong>publiques et légales</strong> (sur internet, dans les journaux, les réseaux sociaux, les registres...)
        et les <strong>recouper</strong> pour comprendre quelque chose.</p>
        <p>Un enquêteur OSINT, c'est un peu le Sherlock Holmes du web : il ne pirate rien, il <strong>observe</strong>,
        <strong>collecte</strong> et <strong>relie les indices</strong> qui sont déjà visibles par tout le monde.</p>
        <h4>À quoi ça sert, concrètement ?</h4>
        <ul>
          <li>🕵️ Un enquêteur retrouve un escroc grâce à ses traces en ligne.</li>
          <li>🏢 Une entreprise vérifie qu'un partenaire est sérieux avant de signer.</li>
          <li>🛡️ Un analyste comprend comment un groupe de pirates fonctionne.</li>
          <li>📰 Un journaliste vérifie si une photo virale est vraie ou truquée.</li>
          <li>🙋 <strong>Toi :</strong> tu vérifies ce qu'on peut trouver sur toi, pour mieux te protéger.</li>
        </ul>
        <div class="callout callout-warning">
          <strong>Important — l'éthique :</strong> l'OSINT n'utilise QUE des informations publiques et de façon légale.
          On n'espionne pas les gens pour leur nuire, on ne harcèle personne. On apprend ici pour
          <strong>se protéger</strong> et comprendre ce que les autres peuvent voir de nous.
        </div>`
    },
    {
      titre: "Le cycle du renseignement",
      html: `
        <p>Les professionnels ne cherchent pas au hasard : ils suivent une méthode en 5 étapes, qu'on appelle
        le <strong>cycle du renseignement</strong>.</p>
        <ol>
          <li>🎯 <strong>Définir le besoin</strong> : que cherche-t-on exactement ? (une question claire)</li>
          <li>🔎 <strong>Collecter</strong> : récolter les informations depuis les sources.</li>
          <li>🧪 <strong>Traiter</strong> : trier, organiser, traduire, nettoyer les données.</li>
          <li>🧩 <strong>Analyser</strong> : relier les indices, vérifier, comprendre ce que ça veut dire.</li>
          <li>📣 <strong>Diffuser</strong> : présenter le résultat clairement à celui qui en a besoin.</li>
        </ol>
        <div class="callout callout-tip">
          La plus grosse erreur du débutant, c'est de sauter l'étape 1. Sans question précise, on se noie dans
          une mer d'informations. Toujours commencer par : <em>« Qu'est-ce que je cherche, précisément ? »</em>
        </div>`
    },
    {
      titre: "Les moteurs de recherche et les 'Google Dorks'",
      html: `
        <p>Le moteur de recherche est l'outil n°1. Mais la plupart des gens ne savent pas s'en servir à fond !
        On peut lui poser des questions très précises grâce à des mots-clés spéciaux appelés
        <strong>« Google Dorks »</strong> (opérateurs de recherche).</p>
        <table class="table">
          <tr><th>Commande</th><th>Ce qu'elle fait</th></tr>
          <tr><td><code>"collège Jean Moulin"</code></td><td>Cherche l'expression <strong>exacte</strong> entre guillemets.</td></tr>
          <tr><td><code>site:education.gouv.fr</code></td><td>Cherche <strong>seulement</strong> sur un site précis.</td></tr>
          <tr><td><code>filetype:pdf</code></td><td>Cherche seulement des fichiers d'un <strong>type</strong> (pdf, docx...).</td></tr>
          <tr><td><code>intitle:rapport</code></td><td>Cherche un mot dans le <strong>titre</strong> de la page.</td></tr>
          <tr><td><code>cyber -virus</code></td><td>Cherche « cyber » <strong>mais exclut</strong> « virus » (le moins).</td></tr>
          <tr><td><code>météo OR climat</code></td><td>Cherche l'un <strong>ou</strong> l'autre.</td></tr>
        </table>
        <p>On peut aussi <strong>combiner</strong> ces commandes :
        <code>site:gouv.fr filetype:pdf "cybersécurité"</code> cherche des PDF contenant « cybersécurité »
        uniquement sur les sites du gouvernement. Puissant !</p>
        <div class="callout callout-info">
          Ces techniques servent aux chercheurs et aux journalistes. Elles montrent aussi à quel point il faut
          faire attention à ce qu'on publie : un document « oublié » en ligne peut être retrouvé facilement.
        </div>`
    },
    {
      titre: "Les métadonnées : les infos invisibles des fichiers",
      html: `
        <p>Quand tu prends une photo avec un téléphone, le fichier ne contient pas <em>que</em> l'image.
        Il contient aussi des <strong>métadonnées</strong> : la date, l'heure, le modèle du téléphone,
        les réglages de l'appareil, et parfois même <strong>l'endroit exact (GPS) où la photo a été prise</strong> !</p>
        <p>Ces informations cachées s'appellent les données <strong>EXIF</strong> pour les photos. Les documents Word
        ou PDF ont aussi des métadonnées : nom de l'auteur, date de création, logiciel utilisé...</p>
        <div class="callout callout-warning">
          <strong>Attention danger :</strong> si tu publies une photo prise chez toi avec le GPS activé, n'importe qui
          peut retrouver ton adresse. Des personnes se sont déjà fait localiser ainsi. C'est pour cela qu'il faut
          vérifier les réglages de son téléphone !
        </div>
        <h4>Comment se protéger ?</h4>
        <ul>
          <li>📍 Désactive la <strong>géolocalisation des photos</strong> dans les réglages de ton téléphone.</li>
          <li>🧹 Beaucoup de réseaux sociaux <strong>nettoient</strong> les métadonnées automatiquement... mais pas tous.</li>
          <li>🔍 Dans le doute, il existe des outils qui effacent les métadonnées avant de partager un fichier.</li>
        </ul>
        <p>Tu vas t'entraîner à lire des métadonnées dans le mini-lab <strong>« Détective métadonnées »</strong> !</p>`
    },
    {
      titre: "Géolocalisation et recherche d'image inversée",
      html: `
        <p>Deux super-pouvoirs de l'OSINT à connaître :</p>
        <h4>1. La géolocalisation d'une image (sans GPS !)</h4>
        <p>Même sans métadonnées GPS, un enquêteur peut deviner <strong>où</strong> une photo a été prise en observant
        les <strong>indices visuels</strong> : une plaque de rue, le style des bâtiments, une montagne reconnaissable,
        une langue sur une enseigne, le type de prises électriques, les panneaux de signalisation... On compare ensuite
        avec des cartes et Street View. C'est un vrai jeu de piste !</p>
        <h4>2. La recherche d'image inversée</h4>
        <p>Au lieu de chercher avec des mots, on cherche <strong>avec une image</strong>. On donne une photo au moteur,
        et il retrouve où elle apparaît ailleurs sur le web. Très utile pour :</p>
        <ul>
          <li>🔍 Vérifier si une photo est <strong>ancienne</strong> (réutilisée pour tromper).</li>
          <li>🎭 Démasquer un <strong>faux profil</strong> qui utilise la photo de quelqu'un d'autre.</li>
          <li>📰 Vérifier une image qui devient virale.</li>
        </ul>
        <div class="callout callout-tip">
          Ces techniques sont très utilisées pour <strong>lutter contre les fausses informations</strong>.
          Une image sortie de son contexte est l'une des arnaques les plus fréquentes sur internet.
        </div>`
    },
    {
      titre: "Vérifier une information et déjouer les fake news",
      html: `
        <p>Trouver une information, c'est bien. Vérifier qu'elle est <strong>vraie</strong>, c'est mieux !
        Sur internet, tout n'est pas fiable, loin de là. Un bon enquêteur OSINT est d'abord quelqu'un de
        <strong>méfiant et méthodique</strong>.</p>
        <h4>Les bons réflexes</h4>
        <ul>
          <li>🔁 <strong>Croiser les sources</strong> : une info confirmée par 3 sources sérieuses et indépendantes est plus fiable.</li>
          <li>📅 <strong>Vérifier la date</strong> : une vieille info peut être ressortie pour tromper.</li>
          <li>🏷️ <strong>Identifier la source</strong> : qui a écrit ça ? Un média sérieux ou un compte anonyme ?</li>
          <li>🖼️ <strong>Vérifier les images</strong> : recherche inversée pour voir si elles sont détournées.</li>
          <li>🧠 <strong>Se méfier des émotions</strong> : une info qui te met très en colère ou très content est faite
          pour être partagée vite... parfois sans être vraie.</li>
        </ul>
        <div class="callout callout-warning">
          <strong>La règle d'or :</strong> avant de partager une information choquante, prends 2 minutes pour vérifier.
          Partager une fausse info, même sans le vouloir, participe à la désinformation.
        </div>`
    },
    {
      titre: "Ton empreinte numérique : se protéger",
      html: `
        <p>Tout ce que tu publies, aimes ou commentes laisse une trace : c'est ton <strong>empreinte numérique</strong>.
        Mises bout à bout, ces traces en disent beaucoup sur toi. Maintenant que tu sais comment les enquêteurs
        cherchent, voici comment te protéger :</p>
        <ul>
          <li>🔒 Mets tes comptes en <strong>privé</strong> et vérifie qui peut voir tes publications.</li>
          <li>📍 <strong>Désactive la géolocalisation</strong> des photos et des applis.</li>
          <li>🤔 Avant de publier, demande-toi : « est-ce que ça me dérangerait que mes parents, un prof ou un
          futur employeur voient ça dans 10 ans ? »</li>
          <li>👤 Ne donne pas ton nom complet, ton adresse, ton collège ou tes horaires à des inconnus.</li>
          <li>🔑 Utilise des mots de passe différents et solides (voir le parcours Pentest).</li>
          <li>🔍 <strong>Google-toi toi-même</strong> régulièrement pour voir ce qui est visible, et demande à faire
          retirer ce qui te dérange (droit à l'oubli).</li>
        </ul>
        <div class="callout callout-tip">
          <strong>À retenir :</strong> sur internet, c'est plus facile de <strong>ne pas publier</strong> une information
          que d'essayer de l'effacer après coup. Réfléchis <strong>avant</strong> de poster.
        </div>`
    }
  ],
  qcm: [
    { q: "Que signifie OSINT ?", choix: ["Un virus", "Renseignement en sources ouvertes", "Un réseau social", "Un mot de passe"], bonne: 1,
      explication: "OSINT = Open Source Intelligence = renseignement en sources ouvertes." },
    { q: "L'OSINT utilise...", choix: ["Du piratage illégal", "Uniquement des informations publiques et légales", "Des virus", "Des caméras cachées"], bonne: 1,
      explication: "L'OSINT n'utilise que des infos publiques, de façon légale et éthique." },
    { q: "Quelle est la 1re étape du cycle du renseignement ?", choix: ["Diffuser", "Définir le besoin (la question)", "Collecter au hasard", "Analyser"], bonne: 1,
      explication: "On commence toujours par définir précisément ce que l'on cherche." },
    { q: "Que fait la commande Google 'site:education.gouv.fr' ?", choix: ["Supprime le site", "Cherche uniquement sur ce site", "Crée un site", "Bloque le site"], bonne: 1,
      explication: "L'opérateur site: limite la recherche à un domaine précis." },
    { q: "Que peut contenir une photo en plus de l'image ?", choix: ["Rien", "Des métadonnées (date, GPS, modèle)", "De la musique", "Un virus garanti"], bonne: 1,
      explication: "Les métadonnées EXIF contiennent date, lieu GPS, modèle d'appareil..." },
    { q: "À quoi sert la recherche d'image inversée ?", choix: ["À créer des images", "À retrouver où une image apparaît ailleurs (détecter faux profils, fake news)", "À colorier", "À supprimer des photos"], bonne: 1,
      explication: "Elle permet de vérifier l'origine d'une image et de démasquer les détournements." },
    { q: "Pour vérifier une information, le meilleur réflexe est de...", choix: ["La partager vite", "Croiser plusieurs sources sérieuses", "Croire le premier site", "Regarder le nombre de likes"], bonne: 1,
      explication: "Croiser des sources indépendantes et fiables est la base de la vérification." },
    { q: "Comment réduire ton empreinte numérique ?", choix: ["Tout publier en public", "Comptes en privé, GPS désactivé, réfléchir avant de poster", "Donner son adresse", "Accepter tous les inconnus"], bonne: 1,
      explication: "Comptes privés, géolocalisation off et prudence avant de publier." }
  ],
  labs: ["osint-metadata", "osint-dork"]
},

/* ========================================================== */
/* 2. PENTEST                                                 */
/* ========================================================== */
{
  id: "pentest",
  titre: "Pentest — Le hacking éthique",
  icone: "⚔️",
  couleur: "#f59e0b",
  resume: "Jouer au 'gentil pirate', avec autorisation, pour trouver les failles avant les méchants.",
  duree: "1 h 15",
  lecons: [
    {
      titre: "Le pentest : attaquer pour mieux défendre",
      html: `
        <p>Un <strong>test d'intrusion</strong> (ou <em>pentest</em>, pour « penetration testing ») consiste à
        <strong>attaquer un système... avec sa permission</strong>, pour trouver ses faiblesses <strong>avant</strong>
        les vrais pirates. C'est comme engager un cambrioleur professionnel pour tester les serrures de sa maison,
        puis renforcer les points faibles qu'il a trouvés.</p>
        <p>Le pentester est un <strong>hacker éthique</strong> : un « gentil pirate ». Son but n'est pas de voler
        ou de casser, mais d'<strong>aider à se protéger</strong>.</p>
        <div class="callout callout-warning">
          <strong>LA règle d'or (à ne JAMAIS oublier) :</strong> on ne teste QUE les systèmes pour lesquels on a une
          <strong>autorisation écrite</strong>. Pirater un système sans permission est <strong>interdit par la loi</strong>
          (en France, article 323-1 du Code pénal : jusqu'à plusieurs années de prison et de fortes amendes),
          même « pour rigoler » ou « juste pour voir ». Sans autorisation, c'est non. Toujours.
        </div>`
    },
    {
      titre: "Chapeaux blancs, noirs et gris",
      html: `
        <p>On classe les hackers par la couleur de leur « chapeau », une image qui vient des vieux films de cowboys
        (les gentils portaient un chapeau blanc, les méchants un noir).</p>
        <div class="grid-cards">
          <div class="mini-card"><div class="mini-icon">🎩</div><h4>White Hat</h4>
            <p>Le gentil. Il agit avec autorisation, pour protéger. C'est le métier de pentester.</p></div>
          <div class="mini-card"><div class="mini-icon">🖤</div><h4>Black Hat</h4>
            <p>Le criminel. Il attaque illégalement pour voler, nuire ou gagner de l'argent.</p></div>
          <div class="mini-card"><div class="mini-icon">🩶</div><h4>Grey Hat</h4>
            <p>Entre les deux. Il agit parfois sans autorisation, même sans mauvaise intention : c'est risqué et souvent illégal.</p></div>
        </div>
        <h4>Le bug bounty : être payé pour trouver des failles</h4>
        <p>Beaucoup de grandes entreprises (Google, Facebook, l'État...) organisent des
        <strong>« bug bounties »</strong> : elles <strong>autorisent</strong> les hackers du monde entier à chercher
        des failles sur leurs sites, et les <strong>récompensent</strong> (parfois plusieurs milliers d'euros !)
        pour chaque faille signalée. C'est une façon légale et bien payée de pratiquer le hacking éthique.</p>
        <div class="callout callout-tip">
          Des jeunes de ton âge participent déjà à des <strong>CTF</strong> (« Capture The Flag »), des compétitions
          de hacking <strong>légales</strong> où l'on résout des énigmes de sécurité. C'est la meilleure façon
          d'apprendre en s'amusant, dans un cadre autorisé.
        </div>`
    },
    {
      titre: "Les étapes d'un test d'intrusion",
      html: `
        <p>Un pentester suit toujours un plan précis, un peu comme un cambrioleur... mais pour aider !</p>
        <ol>
          <li>📝 <strong>Cadrage</strong> : on définit avec le client ce qu'on a le droit de tester (et l'autorisation écrite !).</li>
          <li>🎯 <strong>Reconnaissance</strong> : récolter des infos sur la cible (souvent avec l'OSINT !).</li>
          <li>🔍 <strong>Scan</strong> : chercher les portes d'entrée (ports ouverts, services, versions des logiciels).</li>
          <li>🚪 <strong>Exploitation</strong> : utiliser une faille pour entrer dans le système.</li>
          <li>🧗 <strong>Élévation de privilèges</strong> : devenir « administrateur » pour avoir tous les droits.</li>
          <li>🧹 <strong>Nettoyage</strong> : remettre tout en ordre, sans rien casser ni laisser de trace dangereuse.</li>
          <li>📄 <strong>Rapport</strong> : écrire tout ce qu'on a trouvé et comment le corriger.</li>
        </ol>
        <div class="callout callout-info">
          L'étape la plus importante est le <strong>rapport</strong> ! Trouver une faille ne sert à rien si on
          n'explique pas clairement comment la réparer. Un bon pentester est avant tout un bon <strong>communicant</strong>.
        </div>`
    },
    {
      titre: "Reconnaissance et scan : repérer les portes",
      html: `
        <p>Avant d'attaquer, on observe. Cette phase décide souvent du succès du test.</p>
        <h4>La reconnaissance (passive)</h4>
        <p>On récolte un maximum d'informations <strong>sans toucher à la cible</strong>, grâce à l'OSINT :
        noms des employés, adresses e-mail, technologies utilisées, documents publics... Plus on en sait,
        mieux on prépare le test.</p>
        <h4>Le scan (actif)</h4>
        <p>On « frappe » doucement à toutes les portes de la machine pour voir lesquelles sont ouvertes.
        En informatique, ces portes s'appellent des <strong>ports</strong>. Chaque service (un site web, une
        messagerie, un accès à distance...) utilise un port. Exemples :</p>
        <table class="table">
          <tr><th>Port</th><th>Service</th></tr>
          <tr><td>80 / 443</td><td>Sites web (HTTP / HTTPS sécurisé)</td></tr>
          <tr><td>22</td><td>SSH (connexion à distance sécurisée)</td></tr>
          <tr><td>25</td><td>E-mail (envoi de courriers)</td></tr>
        </table>
        <p>Un port ouvert avec un vieux logiciel pas à jour, c'est souvent une <strong>porte d'entrée</strong> pour
        un attaquant. L'idée de la défense : ne laisser ouvertes que les portes vraiment nécessaires.</p>`
    },
    {
      titre: "Les failles les plus courantes",
      html: `
        <p>Il existe une liste très connue des failles web les plus fréquentes (le « Top 10 » de l'OWASP).
        Voici les plus faciles à comprendre :</p>
        <ul>
          <li>🔑 <strong>Mots de passe faibles</strong> : « 123456 » ou « password » se devinent en une seconde.</li>
          <li>🎣 <strong>Phishing</strong> (hameçonnage) : un faux message pour voler tes identifiants.</li>
          <li>🐛 <strong>Logiciels pas à jour</strong> : les failles non corrigées sont des portes grandes ouvertes.</li>
          <li>💉 <strong>Injection</strong> : glisser du code piégé dans un formulaire d'un site mal protégé
          (par exemple pour lire la base de données).</li>
          <li>🔓 <strong>Mauvaise configuration</strong> : un accès laissé ouvert par erreur, un mot de passe par défaut non changé.</li>
          <li>🤝 <strong>Ingénierie sociale</strong> : manipuler une personne pour qu'elle donne un secret.</li>
        </ul>
        <div class="callout callout-tip">
          La faille n°1, c'est souvent <strong>l'humain</strong> ! Un pirate préfère souvent te <strong>convaincre</strong>
          de donner ton mot de passe plutôt que de casser un système compliqué. C'est plus rapide pour lui.
        </div>`
    },
    {
      titre: "L'ingénierie sociale et le phishing",
      html: `
        <p>L'<strong>ingénierie sociale</strong>, c'est l'art de <strong>manipuler les gens</strong> pour obtenir
        des informations ou un accès, sans rien pirater techniquement. L'attaquant joue sur les émotions :
        la peur, l'urgence, la curiosité, l'envie de rendre service, le respect de l'autorité.</p>
        <h4>Quelques techniques</h4>
        <ul>
          <li>🎣 <strong>Phishing</strong> : un faux e-mail (« votre compte va être bloqué ! ») avec un lien piégé.</li>
          <li>📱 <strong>Smishing</strong> : la même chose par SMS (« votre colis est bloqué, cliquez ici »).</li>
          <li>☎️ <strong>Vishing</strong> : par téléphone (un faux conseiller bancaire, un faux technicien).</li>
          <li>🎭 <strong>Prétexte</strong> : se faire passer pour quelqu'un d'autre (un collègue, un livreur).</li>
        </ul>
        <h4>Comment repérer un piège ?</h4>
        <p>Les signaux d'alerte : un sentiment d'<strong>urgence</strong> ou de <strong>menace</strong>, une
        <strong>adresse bizarre</strong>, des <strong>fautes d'orthographe</strong>, une demande de
        <strong>mot de passe ou d'argent</strong>, une offre <strong>trop belle</strong> pour être vraie.
        En cas de doute : on ne clique pas, et on vérifie par un autre moyen.</p>
        <div class="callout callout-warning">
          <strong>À retenir :</strong> aucune banque, aucun site sérieux ne te demandera jamais ton mot de passe
          par e-mail ou par téléphone. Tu t'entraîneras à repérer les pièges dans le mini-lab « Repère le phishing » !
        </div>`
    },
    {
      titre: "Bien se protéger : mots de passe et double authentification",
      html: `
        <p>Puisque les mots de passe faibles sont une faille majeure, apprenons à bien nous défendre.</p>
        <h4>Un bon mot de passe</h4>
        <ul>
          <li>📏 <strong>Long</strong> : au moins 12 caractères. Plus c'est long, plus c'est dur à casser.</li>
          <li>🔀 <strong>Varié</strong> : majuscules, minuscules, chiffres et symboles.</li>
          <li>🎲 <strong>Imprévisible</strong> : pas ton prénom, pas ta date de naissance, pas « motdepasse ».</li>
          <li>🗝️ <strong>Unique</strong> : un mot de passe différent pour chaque site important.</li>
        </ul>
        <p>Astuce : la <strong>phrase de passe</strong> ! Prends une phrase facile à retenir pour toi :
        <code>MonChat@Mange3Croquettes!</code> — longue, variée, et facile à mémoriser.</p>
        <h4>La double authentification (2FA)</h4>
        <p>C'est une <strong>deuxième serrure</strong>. En plus du mot de passe, le site demande un code reçu
        par SMS ou généré par une appli. Ainsi, même si un pirate connaît ton mot de passe, il ne peut pas entrer
        sans ce deuxième code. <strong>Active-la partout où tu peux</strong> : c'est l'une des protections les plus efficaces.</p>
        <h4>Le gestionnaire de mots de passe</h4>
        <p>Impossible de retenir 50 mots de passe différents ! Un <strong>gestionnaire de mots de passe</strong>
        est un coffre-fort numérique qui les retient pour toi. Tu n'as plus qu'un seul mot de passe « maître » à connaître.</p>
        <p>Teste la solidité d'un mot de passe dans le mini-lab « Testeur de mot de passe » !</p>`
    },
    {
      titre: "Le rapport de pentest : la partie la plus utile",
      html: `
        <p>Un test d'intrusion se termine toujours par un <strong>rapport</strong>. C'est lui qu'on remet au client,
        et c'est grâce à lui que la sécurité va vraiment s'améliorer. Un bon rapport contient :</p>
        <ul>
          <li>📋 Un <strong>résumé</strong> clair pour les chefs (sans jargon) : « voici les gros risques ».</li>
          <li>🐞 La <strong>liste des failles</strong> trouvées, classées par <strong>gravité</strong> (critique, élevée, moyenne, faible).</li>
          <li>🔬 Pour chaque faille : comment elle a été trouvée, et quel est le danger.</li>
          <li>🛠️ Surtout : <strong>comment la corriger</strong> (les recommandations).</li>
        </ul>
        <p>On classe souvent les failles avec un score de gravité (le système <strong>CVSS</strong>, de 0 à 10).
        Cela aide le client à savoir quoi corriger <strong>en premier</strong> : on répare d'abord ce qui est le plus dangereux.</p>
        <div class="callout callout-info">
          <strong>Le bon état d'esprit :</strong> le pentester n'est pas là pour se moquer ou pour faire peur.
          Il est là pour <strong>aider</strong>. Un rapport bien écrit, clair et bienveillant, vaut mille exploits techniques.
        </div>`
    }
  ],
  qcm: [
    { q: "Qu'est-ce qu'un pentester ?", choix: ["Un pirate méchant", "Un hacker éthique qui teste avec autorisation", "Un vendeur d'ordinateurs", "Un virus"], bonne: 1,
      explication: "Le pentester teste les systèmes avec permission : c'est un hacker éthique." },
    { q: "Peut-on tester n'importe quel système sans permission ?", choix: ["Oui, si c'est pour rigoler", "Non, jamais sans autorisation écrite", "Oui, la nuit", "Oui, si on est doué"], bonne: 1,
      explication: "Pirater sans autorisation est illégal, même pour s'amuser (art. 323-1)." },
    { q: "Un 'White Hat' est...", choix: ["Un pirate criminel", "Un hacker éthique et autorisé", "Un virus", "Un antivirus"], bonne: 1,
      explication: "White Hat = chapeau blanc = le gentil, qui agit avec autorisation." },
    { q: "Qu'est-ce qu'un 'bug bounty' ?", choix: ["Un virus", "Une récompense pour avoir signalé une faille (légalement)", "Une amende", "Un jeu vidéo"], bonne: 1,
      explication: "Les entreprises récompensent ceux qui trouvent et signalent des failles." },
    { q: "En informatique, un 'port' ouvert est...", choix: ["Une fenêtre cassée", "Une porte d'entrée possible vers un service", "Un mot de passe", "Un fichier"], bonne: 1,
      explication: "Chaque service utilise un port ; un port ouvert mal protégé est une entrée." },
    { q: "Quelle est l'étape la plus importante d'un pentest ?", choix: ["L'exploitation", "Le rapport final (avec les corrections)", "Le scan", "Rien"], bonne: 1,
      explication: "Le rapport permet de corriger les failles : c'est tout le but." },
    { q: "L'ingénierie sociale, c'est...", choix: ["Manipuler une personne pour obtenir un secret", "Construire un réseau social", "Un virus", "Un logiciel"], bonne: 0,
      explication: "On manipule l'humain plutôt que de casser la technique." },
    { q: "La double authentification (2FA) sert à...", choix: ["Ralentir le PC", "Ajouter une 2e serrure en plus du mot de passe", "Supprimer les mots de passe", "Créer des virus"], bonne: 1,
      explication: "Même si le mot de passe est volé, le 2e code bloque l'intrus." },
    { q: "Lequel est un BON mot de passe ?", choix: ["123456", "password", "MonChat@Mange3Croquettes!", "ton prénom"], bonne: 2,
      explication: "Long, varié, imprévisible et unique : c'est le bon !" }
  ],
  labs: ["pentest-password", "pentest-phishing"]
},

/* ========================================================== */
/* 3. FORENSIC                                                */
/* ========================================================== */
{
  id: "forensic",
  titre: "Forensic — L'investigation numérique",
  icone: "🔬",
  couleur: "#10b981",
  resume: "Mener l'enquête après une attaque, comme un policier scientifique.",
  duree: "1 h 10",
  lecons: [
    {
      titre: "Le forensic : la police scientifique du numérique",
      html: `
        <p>Le <strong>forensic</strong> (ou « investigation numérique », « inforensique ») consiste à
        <strong>enquêter après un incident</strong>. Un système a été piraté ? L'analyste forensic arrive,
        comme un enquêteur de la police scientifique sur une scène de crime, pour répondre à quatre questions :
        <strong>Que s'est-il passé ? Comment ? Quand ? Qui ?</strong></p>
        <p>Il cherche des <strong>preuves numériques</strong> : fichiers, journaux (logs), traces de connexion,
        mémoire de l'ordinateur, historiques... Et il doit être extrêmement <strong>rigoureux</strong>, car ces
        preuves peuvent servir devant un <strong>tribunal</strong>.</p>
        <div class="callout callout-info">
          <strong>Règle n°1 du forensic :</strong> on ne modifie JAMAIS la preuve d'origine. On travaille toujours
          sur une <strong>copie exacte</strong> (une « image »), pour ne pas abîmer les indices. Comme un enquêteur
          qui met des gants pour ne pas effacer les empreintes.
        </div>`
    },
    {
      titre: "Les types de preuves numériques",
      html: `
        <p>Une scène de crime numérique regorge d'indices. L'analyste sait où regarder :</p>
        <table class="table">
          <tr><th>Preuve</th><th>Ce qu'elle révèle</th></tr>
          <tr><td>📜 <strong>Les logs (journaux)</strong></td><td>Qui s'est connecté, quand, ce qui a été fait.</td></tr>
          <tr><td>📁 <strong>Les fichiers</strong></td><td>Documents volés, programmes malveillants, traces laissées.</td></tr>
          <tr><td>🗑️ <strong>Les fichiers supprimés</strong></td><td>Souvent récupérables ! Effacer ne détruit pas tout de suite.</td></tr>
          <tr><td>🧠 <strong>La mémoire vive (RAM)</strong></td><td>Ce qui tournait au moment de l'incident (mots de passe, programmes actifs).</td></tr>
          <tr><td>🌐 <strong>Le trafic réseau</strong></td><td>Avec qui la machine communiquait (serveur du pirate ?).</td></tr>
          <tr><td>🕑 <strong>Les dates des fichiers</strong></td><td>Création, modification, dernier accès : pour reconstituer la chronologie.</td></tr>
        </table>
        <div class="callout callout-tip">
          <strong>Surprenant :</strong> quand tu « supprimes » un fichier, il n'est pas vraiment effacé tout de suite.
          L'ordinateur marque juste la place comme « libre ». Tant que rien ne vient par-dessus, un spécialiste
          peut souvent le récupérer. C'est pratique pour les enquêtes... et une raison de plus de bien effacer
          un appareil avant de le revendre !
        </div>`
    },
    {
      titre: "Les logs : le journal de bord de l'ordinateur",
      html: `
        <p>Un <strong>log</strong> (journal), c'est une ligne de texte que l'ordinateur écrit automatiquement à
        chaque événement : une connexion, une erreur, un fichier ouvert, un programme lancé... C'est la
        <strong>source n°1</strong> de l'enquêteur.</p>
        <p>Exemple d'une ligne de log de connexion :</p>
        <pre class="code-block">2026-01-15 03:14:07  LOGIN  utilisateur=admin  ip=185.23.44.9  statut=ÉCHEC</pre>
        <p>Décortiquons-la : à <strong>3h14 du matin</strong> (heure bizarre !), quelqu'un a essayé de se connecter
        avec le compte « admin », depuis une <strong>adresse inconnue</strong>, et ça a <strong>échoué</strong>.
        Si on voit ça répété 500 fois de suite, c'est sûrement une <strong>attaque par force brute</strong>
        (le pirate essaie des milliers de mots de passe à la chaîne).</p>
        <h4>Ce que l'enquêteur cherche</h4>
        <ul>
          <li>🕐 Une <strong>heure anormale</strong> (la nuit, un dimanche...).</li>
          <li>🌍 Une <strong>adresse inconnue</strong> ou venant de l'étranger.</li>
          <li>❌ Beaucoup d'<strong>échecs</strong> suivis d'une <strong>réussite</strong> (= le pirate a fini par trouver).</li>
          <li>📈 Un <strong>volume anormal</strong> (des milliers d'actions en quelques secondes).</li>
        </ul>
        <div class="callout callout-tip">
          Tu t'entraîneras à repérer l'intrus dans le mini-lab « Analyse de logs » !
        </div>`
    },
    {
      titre: "Reconstituer la chronologie (timeline)",
      html: `
        <p>Le cœur du métier, c'est de <strong>raconter l'histoire de l'attaque</strong> dans l'ordre, du début à la fin.
        On appelle ça construire la <strong>timeline</strong> (chronologie). C'est comme assembler les pièces d'un puzzle
        pour comprendre le film complet.</p>
        <p>Exemple de timeline reconstituée :</p>
        <table class="table">
          <tr><th>Heure</th><th>Événement</th></tr>
          <tr><td>03:14</td><td>Attaque par force brute sur le compte admin (nombreux échecs).</td></tr>
          <tr><td>03:14:12</td><td>Connexion réussie : le pirate est entré.</td></tr>
          <tr><td>03:20</td><td>Téléchargement d'un programme malveillant.</td></tr>
          <tr><td>03:35</td><td>Copie de fichiers sensibles vers un serveur externe (vol de données).</td></tr>
          <tr><td>04:02</td><td>Effacement des logs pour masquer les traces.</td></tr>
        </table>
        <p>Grâce à cette reconstitution, on comprend <strong>comment</strong> le pirate est entré (pour fermer la faille),
        <strong>ce qu'il a volé</strong> (pour mesurer les dégâts) et <strong>ce qu'il faut corriger</strong>.</p>
        <div class="callout callout-info">
          Les pirates essaient souvent d'<strong>effacer les logs</strong> pour cacher leur passage. C'est pourquoi
          on envoie souvent les logs <strong>en temps réel vers un autre serveur protégé</strong> : même si le pirate
          efface ceux de la machine, la copie reste intacte.
        </div>`
    },
    {
      titre: "Décoder : Base64, hexadécimal, ASCII",
      html: `
        <p>Les données ne sont pas toujours lisibles directement. L'enquêteur doit savoir les <strong>décoder</strong>.</p>
        <h4>Le code ASCII</h4>
        <p>Les ordinateurs ne connaissent que des nombres. Pour écrire du texte, on a attribué un numéro à chaque
        caractère : c'est le code <strong>ASCII</strong>. Par exemple, la lettre « A » majuscule = <strong>65</strong>,
        « B » = 66, « a » minuscule = 97.</p>
        <h4>Le Base64</h4>
        <p>C'est une façon de transformer n'importe quelle donnée (texte, image, fichier) en une suite de lettres
        et de chiffres. <strong>Ce n'est PAS du chiffrement</strong> (ce n'est pas secret !), juste un « emballage »
        pour transporter des données. Exemple : <code>Qm9uam91cg==</code> veut dire <code>Bonjour</code>.
        On reconnaît souvent le Base64 au <code>=</code> à la fin.</p>
        <h4>L'hexadécimal</h4>
        <p>Au lieu de compter avec 10 chiffres (0-9), on compte avec 16 symboles : 0-9 puis A, B, C, D, E, F.
        C'est pratique car les ordinateurs fonctionnent par paquets. La lettre « A » (65 en ASCII) s'écrit
        <code>41</code> en hexadécimal. On s'en sert pour lire le « vrai » contenu des fichiers (l'éditeur hexa).</p>
        <div class="callout callout-tip">
          Tu décoderas un message secret dans le mini-lab « Décodeur de messages » !
        </div>`
    },
    {
      titre: "Introduction au chiffrement",
      html: `
        <p>Attention à ne pas confondre : <strong>encoder</strong> (Base64) n'est pas secret, alors que
        <strong>chiffrer</strong>, c'est rendre un message <strong>illisible sans la clé</strong>. Le chiffrement,
        c'est le vrai secret.</p>
        <h4>Le chiffre de César (le plus ancien)</h4>
        <p>Jules César, il y a 2000 ans, décalait chaque lettre de 3 rangs dans l'alphabet pour cacher ses messages.
        A devient D, B devient E, C devient F... Le « 3 » est la <strong>clé</strong>. Pour lire, il faut connaître
        la clé et décaler dans l'autre sens.</p>
        <pre class="code-block">Message clair :  BONJOUR
Décalage de 3 :  ERQMRXU</pre>
        <p>C'est amusant, mais très facile à casser aujourd'hui (il n'y a que 25 décalages possibles à essayer !).</p>
        <h4>Le chiffrement moderne</h4>
        <p>Aujourd'hui, on utilise des méthodes mathématiques très puissantes (comme <strong>AES</strong>).
        Le chiffrement protège tes messages (applications sécurisées), tes paiements, et les données sur ton téléphone.
        Quand tu vois le petit <strong>cadenas 🔒</strong> et <strong>« https »</strong> dans ton navigateur,
        c'est que la connexion est chiffrée !</p>
        <div class="callout callout-tip">
          Tu casseras un message chiffré à la César dans le mini-lab « Chiffre de César » !
        </div>`
    },
    {
      titre: "La chaîne de preuve et le rapport",
      html: `
        <p>Une enquête forensic suit des étapes rigoureuses :</p>
        <ol>
          <li>🧊 <strong>Figer la scène</strong> : isoler la machine pour ne rien perdre ni modifier.</li>
          <li>💾 <strong>Copier</strong> : faire une copie exacte des disques (on travaille sur la copie, jamais l'original).</li>
          <li>🔎 <strong>Analyser</strong> : fouiller les logs, les fichiers, la mémoire.</li>
          <li>🧩 <strong>Reconstituer</strong> : construire la timeline de l'attaque.</li>
          <li>📄 <strong>Rapporter</strong> : écrire un rapport clair, prouvé et honnête.</li>
        </ol>
        <h4>La chaîne de preuve</h4>
        <p>On parle de <strong>« chaîne de preuve »</strong> (ou chaîne de custody) : on doit pouvoir prouver que
        <strong>personne n'a trafiqué les indices</strong> entre la découverte et le tribunal. On note tout :
        qui a touché quoi, quand, comment. Pour garantir qu'une copie est identique à l'original, on calcule une
        <strong>empreinte numérique</strong> (un « hash ») : si un seul octet change, l'empreinte change complètement.</p>
        <div class="callout callout-info">
          <strong>Image :</strong> le hash, c'est comme le sceau de cire sur une lettre ancienne. Si le sceau est
          intact, on sait que personne n'a ouvert la lettre. Si l'empreinte correspond, on sait que la preuve
          n'a pas été modifiée.
        </div>`
    }
  ],
  qcm: [
    { q: "Quand intervient l'analyste forensic ?", choix: ["Avant l'attaque", "Après un incident, pour enquêter", "Jamais", "Pendant les vacances"], bonne: 1,
      explication: "Le forensic enquête après l'incident pour comprendre ce qui s'est passé." },
    { q: "Pourquoi travaille-t-on sur une COPIE des preuves ?", choix: ["Pour aller plus vite", "Pour ne pas abîmer la preuve d'origine", "Par flemme", "Ça ne sert à rien"], bonne: 1,
      explication: "On ne modifie jamais l'original : on travaille sur une copie exacte." },
    { q: "Un fichier 'supprimé' est...", choix: ["Détruit instantanément et pour toujours", "Souvent récupérable tant que rien n'est écrit par-dessus", "Transformé en virus", "Envoyé au pirate"], bonne: 1,
      explication: "La suppression marque la place comme libre : le fichier reste souvent récupérable." },
    { q: "Une connexion 'admin' à 3h du matin avec 500 échecs puis un OK, c'est...", choix: ["Normal", "Une attaque par force brute réussie", "Une mise à jour", "Une blague"], bonne: 1,
      explication: "Beaucoup d'échecs la nuit suivis d'un succès = force brute réussie." },
    { q: "Le Base64, c'est...", choix: ["Un chiffrement ultra-secret", "Un encodage (emballage) du texte, pas un secret", "Un virus", "Un mot de passe"], bonne: 1,
      explication: "Le Base64 encode mais ne rend pas secret : tout le monde peut le décoder." },
    { q: "Quelle est la différence entre encoder et chiffrer ?", choix: ["Aucune", "Chiffrer rend illisible sans la clé ; encoder non", "Encoder est plus secret", "Les deux sont des virus"], bonne: 1,
      explication: "Chiffrer = vrai secret (clé nécessaire). Encoder = simple transformation réversible." },
    { q: "Le chiffre de César consiste à...", choix: ["Décaler les lettres de l'alphabet", "Supprimer des lettres", "Ajouter des chiffres", "Traduire en anglais"], bonne: 0,
      explication: "On décale chaque lettre d'un nombre fixe (la clé)." },
    { q: "Comment appelle-t-on le suivi rigoureux et prouvé des preuves ?", choix: ["La chaîne de preuve", "Le wifi", "Le cloud", "Le bug"], bonne: 0,
      explication: "La chaîne de preuve garantit que les indices n'ont pas été trafiqués." }
  ],
  labs: ["forensic-logs", "forensic-decoder", "forensic-cesar"]
},

/* ========================================================== */
/* 4. ANALYSTE SOC                                            */
/* ========================================================== */
{
  id: "soc",
  titre: "Analyste SOC — La tour de contrôle",
  icone: "🔍",
  couleur: "#ef4444",
  resume: "Surveiller, détecter et réagir aux attaques en temps réel.",
  duree: "1 h 05",
  lecons: [
    {
      titre: "Le SOC : la tour de contrôle de la sécurité",
      html: `
        <p>Un <strong>SOC</strong> (« Security Operations Center », centre des opérations de sécurité) est une
        <strong>salle de surveillance</strong>. Imagine la tour de contrôle d'un aéroport, mais pour les cyberattaques :
        des grands écrans, des alertes, et des analystes qui veillent.</p>
        <p>Des <strong>analystes SOC</strong> y travaillent, souvent <strong>24h/24 et 7j/7</strong> (en se relayant),
        car les attaques n'attendent pas les heures de bureau. Leur mission : <strong>repérer les attaques le plus
        vite possible</strong> et donner l'alerte.</p>
        <div class="callout callout-info">
          <strong>Chaque minute compte :</strong> plus on détecte une attaque tôt, moins elle fait de dégâts.
          On mesure même deux temps clés : le temps pour <strong>détecter</strong> une attaque (MTTD) et le temps
          pour <strong>réagir</strong> (MTTR). Les bons SOC cherchent à les réduire au maximum.
        </div>`
    },
    {
      titre: "Le SIEM : l'outil qui voit tout",
      html: `
        <p>Les analystes ne peuvent pas lire des millions de lignes de logs à la main. Ils utilisent un outil central :
        le <strong>SIEM</strong>. C'est un programme qui <strong>rassemble tous les logs</strong> de toute l'entreprise
        (ordinateurs, serveurs, pare-feu...) au même endroit, et qui <strong>lève une alerte</strong> dès que quelque
        chose semble suspect.</p>
        <p>Le SIEM applique des <strong>règles</strong> : « si un compte échoue 50 fois à se connecter en 1 minute →
        alerte ! », « si quelqu'un se connecte depuis deux pays différents en 5 minutes → alerte ! » (impossible
        physiquement, donc suspect).</p>
        <h4>Vrai positif ou faux positif ?</h4>
        <p>Toutes les alertes ne sont pas de vraies attaques :</p>
        <table class="table">
          <tr><th>Type</th><th>Explication</th></tr>
          <tr><td>🔴 <strong>Vrai positif</strong></td><td>Une vraie attaque. Il faut agir vite !</td></tr>
          <tr><td>🟡 <strong>Faux positif</strong></td><td>Fausse alerte (ex : un employé qui travaille tard). Pas de danger.</td></tr>
          <tr><td>⚫ <strong>Faux négatif</strong></td><td>Le pire : une vraie attaque que le SIEM n'a PAS détectée.</td></tr>
        </table>
        <div class="callout callout-tip">
          Le travail de l'analyste, c'est le <strong>tri (triage)</strong> : séparer les vraies alertes des fausses,
          pour ne pas s'épuiser sur de fausses pistes et ne rien rater d'important. Tu t'y entraîneras dans le
          mini-lab « Centre d'alertes » !
        </div>`
    },
    {
      titre: "Les niveaux L1, L2, L3 et l'escalade",
      html: `
        <p>Dans un SOC, il y a plusieurs niveaux d'analystes, un peu comme des niveaux dans un jeu vidéo :</p>
        <ul>
          <li><strong>Niveau 1 (L1)</strong> — le premier filtre : il trie les alertes au fur et à mesure et traite les plus simples.</li>
          <li><strong>Niveau 2 (L2)</strong> — l'enquêteur : il analyse en profondeur les alertes compliquées.</li>
          <li><strong>Niveau 3 (L3)</strong> — l'expert : il gère les attaques les plus graves et chasse les menaces cachées (« threat hunting »).</li>
        </ul>
        <p>Quand une alerte est trop difficile pour un niveau, il la « <strong>fait monter</strong> » (escalade)
        au niveau supérieur. C'est le <strong>travail d'équipe</strong> qui fait la force du SOC : chacun son rôle,
        comme dans un hôpital (infirmier, médecin, chirurgien).</p>
        <div class="callout callout-info">
          Savoir <strong>quand demander de l'aide</strong> est une qualité, pas une faiblesse. Un bon analyste L1
          sait reconnaître ce qui le dépasse et passe le relais rapidement.
        </div>`
    },
    {
      titre: "Les indicateurs de compromission (IOC)",
      html: `
        <p>Un <strong>IOC</strong> (« Indicator Of Compromise », indicateur de compromission) est un
        <strong>indice qui prouve qu'une attaque a eu lieu</strong>. C'est comme l'empreinte digitale du pirate.
        Quand on en trouve un, on peut chercher s'il apparaît ailleurs pour mesurer l'étendue de l'attaque.</p>
        <p>Quelques exemples d'IOC :</p>
        <ul>
          <li>🌐 Une <strong>adresse IP</strong> connue pour être malveillante.</li>
          <li>🔗 Un <strong>nom de site</strong> utilisé par les pirates.</li>
          <li>🧬 L'<strong>empreinte (hash)</strong> d'un fichier virus connu.</li>
          <li>📧 Une <strong>adresse e-mail</strong> qui envoie du phishing.</li>
        </ul>
        <p>Les défenseurs du monde entier <strong>partagent</strong> ces indicateurs (c'est la « threat intelligence »,
        le renseignement sur les menaces). Ainsi, si une entreprise se fait attaquer, les autres peuvent se protéger
        à l'avance en bloquant ces IOC.</p>
        <div class="callout callout-tip">
          <strong>La force du collectif :</strong> en cybersécurité, les défenseurs coopèrent beaucoup. Une menace
          repérée quelque part protège tout le monde ailleurs.
        </div>`
    },
    {
      titre: "Comprendre les attaques : MITRE ATT&CK",
      html: `
        <p>Pour bien se défendre, il faut comprendre comment les attaquants procèdent. Des experts ont créé une
        grande « encyclopédie » des techniques d'attaque, appelée <strong>MITRE ATT&CK</strong>. C'est comme un
        livre qui décrit toutes les « ruses » connues des pirates, étape par étape.</p>
        <p>Une attaque se déroule souvent selon des grandes phases :</p>
        <ol>
          <li>🎯 <strong>Reconnaissance</strong> : le pirate étudie sa cible.</li>
          <li>🚪 <strong>Accès initial</strong> : il entre (phishing, faille...).</li>
          <li>🏠 <strong>Installation</strong> : il s'installe durablement.</li>
          <li>🧗 <strong>Élévation</strong> : il obtient plus de droits.</li>
          <li>👀 <strong>Déplacement</strong> : il explore le réseau.</li>
          <li>💰 <strong>Objectif</strong> : il vole, chiffre ou détruit les données.</li>
        </ol>
        <div class="callout callout-info">
          Connaître ces étapes aide l'analyste à <strong>anticiper</strong> : s'il repère un pirate à l'étape 2,
          il peut l'arrêter avant l'étape 6. C'est tout l'intérêt de bien comprendre l'ennemi.
        </div>`
    },
    {
      titre: "La réponse à incident",
      html: `
        <p>Quand une vraie attaque est confirmée, on suit un plan de <strong>réponse à incident</strong>.
        Il y a 6 étapes classiques, faciles à retenir :</p>
        <ol>
          <li>🛠️ <strong>Préparer</strong> : avoir les outils et le plan prêts <em>avant</em> l'attaque.</li>
          <li>🚨 <strong>Détecter</strong> : repérer l'attaque (merci le SIEM).</li>
          <li>✋ <strong>Contenir</strong> : isoler la machine infectée pour empêcher la propagation.</li>
          <li>🧹 <strong>Éradiquer</strong> : supprimer le virus, fermer la faille utilisée.</li>
          <li>🔄 <strong>Rétablir</strong> : remettre les systèmes en marche, proprement.</li>
          <li>📚 <strong>Apprendre</strong> : analyser pour que ça ne se reproduise pas.</li>
        </ol>
        <div class="callout callout-tip">
          La dernière étape (« apprendre ») est précieuse : chaque attaque est une leçon pour devenir plus fort.
          Les meilleurs SOC progressent surtout grâce à ce retour d'expérience.
        </div>
        <div class="callout callout-warning">
          <strong>Le bon réflexe en cas d'incident :</strong> ne pas paniquer, ne pas tout éteindre n'importe comment
          (on risque d'effacer des preuves utiles au forensic !), et suivre le plan prévu. Rester calme et méthodique.
        </div>`
    }
  ],
  qcm: [
    { q: "Qu'est-ce qu'un SOC ?", choix: ["Une chaussette", "Un centre de surveillance de la sécurité", "Un virus", "Un réseau social"], bonne: 1,
      explication: "SOC = centre des opérations de sécurité, la tour de contrôle." },
    { q: "À quoi sert un SIEM ?", choix: ["À jouer", "À rassembler les logs et lever des alertes", "À envoyer des mails", "À dessiner"], bonne: 1,
      explication: "Le SIEM centralise les logs et déclenche des alertes." },
    { q: "Un employé se connecte tard, l'alerte sonne mais ce n'est rien. C'est un...", choix: ["Vrai positif", "Faux positif", "Virus", "Bug"], bonne: 1,
      explication: "Fausse alerte = faux positif." },
    { q: "Le pire des cas pour un SOC, c'est...", choix: ["Un faux positif", "Un faux négatif (attaque non détectée)", "Trop d'alertes", "Un café renversé"], bonne: 1,
      explication: "Un faux négatif = une vraie attaque passée inaperçue. Le plus dangereux." },
    { q: "Que fait un analyste quand une alerte est trop compliquée ?", choix: ["Il l'ignore", "Il l'escalade au niveau supérieur (L2/L3)", "Il éteint tout", "Il part"], bonne: 1,
      explication: "On escalade l'alerte aux analystes de niveau supérieur." },
    { q: "Qu'est-ce qu'un IOC ?", choix: ["Un indice prouvant une attaque (IP, hash...)", "Un jeu", "Un antivirus", "Un mot de passe"], bonne: 0,
      explication: "Un indicateur de compromission est une 'empreinte' laissée par l'attaque." },
    { q: "Quelle est la 3e étape de la réponse à incident ?", choix: ["Contenir (isoler)", "Faire une pause", "Supprimer tout sans réfléchir", "Rien"], bonne: 0,
      explication: "Après préparer et détecter, on contient pour éviter la propagation." },
    { q: "Pourquoi ne faut-il pas tout éteindre brutalement pendant un incident ?", choix: ["Ça use l'ordinateur", "On risque d'effacer des preuves utiles au forensic", "Ça coûte cher", "Aucune raison"], bonne: 1,
      explication: "Certaines preuves (ex : la mémoire vive) disparaissent si on éteint mal." }
  ],
  labs: ["soc-triage"]
},

/* ========================================================== */
/* 5. ARCHITECTE CYBER                                        */
/* ========================================================== */
{
  id: "archi",
  titre: "Architecte Cyber — Construire les défenses",
  icone: "🏗️",
  couleur: "#8b5cf6",
  resume: "Concevoir des systèmes solides et bien protégés, comme un architecte dessine une forteresse.",
  duree: "1 h 05",
  lecons: [
    {
      titre: "L'architecte cyber : le plan de la forteresse",
      html: `
        <p>L'<strong>architecte cybersécurité</strong> conçoit les <strong>défenses</strong> d'un système informatique,
        comme un architecte dessine les plans d'un château fort : où placer les murs, les douves, les portes, les gardes,
        les issues de secours... Son objectif : rendre la vie <strong>très difficile</strong> aux attaquants.</p>
        <p>C'est un métier de <strong>réflexion et d'anticipation</strong> : il faut imaginer toutes les façons dont
        un pirate pourrait attaquer, et prévoir une protection pour chacune, <strong>avant</strong> la construction.
        Corriger un plan sur le papier coûte bien moins cher que de tout refaire une fois construit !</p>
        <div class="callout callout-info">
          <strong>« Security by design » :</strong> la sécurité doit être pensée dès le début, pas rajoutée à la fin.
          Une maison avec des portes blindées prévues dès les plans est bien plus sûre qu'une maison où on ajoute
          des verrous après coup.
        </div>`
    },
    {
      titre: "La défense en profondeur",
      html: `
        <p>Le grand principe de l'architecte, c'est la <strong>défense en profondeur</strong> :
        ne jamais compter sur UNE seule protection, mais en <strong>empiler plusieurs</strong>, les unes derrière
        les autres.</p>
        <p>Comme un château fort : même si l'ennemi franchit le premier mur, il y a les douves, puis un deuxième mur,
        puis la tour, puis les gardes... Si <strong>une protection tombe, les autres tiennent</strong> et ralentissent
        l'attaquant.</p>
        <div class="grid-cards">
          <div class="mini-card"><div class="mini-icon">🧱</div><h4>Pare-feu</h4><p>Un mur qui filtre qui entre et qui sort du réseau.</p></div>
          <div class="mini-card"><div class="mini-icon">🦠</div><h4>Antivirus / EDR</h4><p>Détecte et bloque les programmes malveillants.</p></div>
          <div class="mini-card"><div class="mini-icon">🔐</div><h4>Chiffrement</h4><p>Rend les données illisibles sans la clé.</p></div>
          <div class="mini-card"><div class="mini-icon">👤</div><h4>Authentification</h4><p>Vérifie l'identité (mot de passe + 2FA).</p></div>
          <div class="mini-card"><div class="mini-icon">💾</div><h4>Sauvegardes</h4><p>Des copies pour tout restaurer après un pépin.</p></div>
          <div class="mini-card"><div class="mini-icon">🎓</div><h4>Formation</h4><p>Des utilisateurs vigilants : la meilleure défense !</p></div>
        </div>
        <p>Tu t'entraîneras à associer chaque menace à la bonne défense dans le mini-lab « Construis ta défense » !</p>`
    },
    {
      titre: "Moindre privilège et Zero Trust",
      html: `
        <h4>1. Le moindre privilège</h4>
        <p>Chaque personne (et chaque programme) n'a que les droits dont elle a <strong>vraiment besoin</strong>,
        rien de plus. Un élève n'a pas besoin de la clé du bureau du directeur ! En informatique, on ne donne pas
        les droits « administrateur » à tout le monde : ainsi, si un compte est piraté, les dégâts sont limités.</p>
        <h4>2. Le Zero Trust (« ne jamais faire confiance par défaut »)</h4>
        <p>L'ancienne idée était : « à l'intérieur de l'entreprise, tout le monde est de confiance ». Mauvaise idée !
        Le <strong>Zero Trust</strong> dit l'inverse : on ne fait <strong>confiance à personne automatiquement</strong>,
        même à l'intérieur. À chaque accès, on redemande : « qui es-tu ? prouve-le ». Comme un videur qui revérifie
        les billets à chaque porte, même pour quelqu'un déjà entré.</p>
        <div class="callout callout-tip">
          <strong>Pourquoi c'est malin :</strong> beaucoup d'attaques viennent de l'intérieur (un compte volé, un
          employé piégé). Avec le Zero Trust, un intrus qui a réussi à entrer ne peut pas se promener librement partout.
        </div>`
    },
    {
      titre: "Segmenter le réseau",
      html: `
        <p>Un bon architecte <strong>découpe le réseau en zones</strong> séparées (la <strong>segmentation</strong>),
        comme les <strong>portes coupe-feu</strong> dans un immeuble. Si le feu (le virus) prend dans une pièce,
        il ne se propage pas partout.</p>
        <p>Exemple : les ordinateurs des élèves, ceux des professeurs et les serveurs importants sont placés dans des
        <strong>zones différentes</strong>, séparées par des pare-feux. Si un ordinateur élève est infecté, le virus
        ne peut pas sauter directement sur les serveurs. Malin, non ?</p>
        <h4>La DMZ : la zone tampon</h4>
        <p>Les serveurs accessibles depuis internet (comme un site web public) sont placés dans une zone spéciale
        appelée <strong>DMZ</strong> (zone démilitarisée). C'est une sorte de <strong>sas d'entrée</strong> :
        même si un pirate pirate le site web public, il se retrouve coincé dans la DMZ et ne peut pas atteindre
        directement le cœur sensible de l'entreprise.</p>
        <div class="callout callout-tip">
          Retiens l'idée : <strong>cloisonner</strong>, c'est limiter les dégâts. Un seul grand espace ouvert =
          un virus qui se balade partout. Des zones séparées = les dégâts restent confinés.
        </div>`
    },
    {
      titre: "Le chiffrement et le HTTPS",
      html: `
        <p>Le <strong>chiffrement</strong> est l'un des outils préférés de l'architecte. Il protège les données
        de deux façons :</p>
        <ul>
          <li>📦 <strong>Au repos</strong> : les données stockées (sur un disque, un téléphone) sont chiffrées.
          Si on vole l'appareil, les données restent illisibles.</li>
          <li>🚚 <strong>En transit</strong> : les données qui circulent sur internet sont chiffrées, pour qu'on
          ne puisse pas les lire au passage.</li>
        </ul>
        <h4>Le fameux cadenas 🔒 (HTTPS)</h4>
        <p>Quand tu vois <strong>« https »</strong> et un petit <strong>cadenas</strong> dans la barre de ton navigateur,
        cela signifie que la connexion entre ton appareil et le site est <strong>chiffrée</strong>. Personne ne peut
        lire ce que tu échanges (ton mot de passe, ton numéro de carte...). Le « s » de https veut dire
        <strong>« secure »</strong> (sécurisé).</p>
        <div class="callout callout-warning">
          <strong>Réflexe utile :</strong> avant de saisir un mot de passe ou un paiement, vérifie la présence du
          <strong>https</strong> et du cadenas. Mais attention : le cadenas prouve que la connexion est chiffrée,
          pas forcément que le site est honnête ! Vérifie aussi que l'adresse du site est la bonne (gare aux fautes
          qui imitent un vrai site).
        </div>`
    },
    {
      titre: "Les sauvegardes et la continuité (règle 3-2-1)",
      html: `
        <p>Même avec les meilleures défenses, un incident peut arriver (panne, incendie, ransomware...).
        L'architecte prévoit toujours un <strong>plan B</strong> : les <strong>sauvegardes</strong>.</p>
        <h4>La règle 3-2-1</h4>
        <p>C'est la règle d'or de la sauvegarde :</p>
        <ul>
          <li><strong>3</strong> copies de tes données importantes,</li>
          <li>sur <strong>2</strong> supports différents (ex : disque dur + cloud),</li>
          <li>dont <strong>1</strong> conservée <strong>ailleurs</strong> (hors du bâtiment).</li>
        </ul>
        <p>Ainsi, même un incendie ou un vol qui détruit tout sur place ne fait pas perdre les données : la copie
        extérieure reste intacte.</p>
        <h4>PRA et PCA</h4>
        <p>Les entreprises préparent aussi :</p>
        <ul>
          <li>Un <strong>PRA</strong> (Plan de Reprise d'Activité) : comment <strong>repartir</strong> après un gros incident.</li>
          <li>Un <strong>PCA</strong> (Plan de Continuité d'Activité) : comment <strong>continuer à fonctionner</strong>
          même pendant l'incident.</li>
        </ul>
        <div class="callout callout-tip">
          <strong>Conseil perso :</strong> fais des sauvegardes de tes propres fichiers importants (photos, devoirs) !
          Un disque qui tombe en panne, ça arrive. Une copie sur un cloud ou un disque externe peut te sauver la mise.
        </div>`
    },
    {
      titre: "Ne pas oublier la sécurité physique et humaine",
      html: `
        <p>La meilleure cybersécurité du monde ne sert à rien si quelqu'un peut simplement <strong>entrer dans la
        salle des serveurs</strong> et débrancher une machine, ou regarder par-dessus ton épaule pendant que tu
        tapes ton mot de passe !</p>
        <h4>La sécurité physique</h4>
        <ul>
          <li>🚪 Portes verrouillées, badges d'accès pour les locaux sensibles.</li>
          <li>📷 Caméras de surveillance.</li>
          <li>🔌 Serveurs dans des salles protégées (contre le feu, l'eau, les coupures de courant).</li>
          <li>💻 Verrouiller sa session quand on quitte son bureau (même 2 minutes !).</li>
        </ul>
        <h4>Le maillon humain</h4>
        <p>On l'a vu tout au long de la semaine : l'humain est souvent la cible n°1. C'est pourquoi l'architecte
        prévoit aussi la <strong>formation</strong> et la <strong>sensibilisation</strong> des employés. Un personnel
        vigilant, qui sait repérer un phishing et qui a de bons réflexes, vaut toutes les technologies du monde.</p>
        <div class="callout callout-info">
          <strong>La grande leçon de la semaine :</strong> la cybersécurité, c'est un mélange de <strong>technique</strong>,
          d'<strong>organisation</strong> (les règles) et d'<strong>humain</strong>. Les trois ensemble. Et ça
          concerne tout le monde, toi y compris !
        </div>`
    }
  ],
  qcm: [
    { q: "Que fait l'architecte cyber ?", choix: ["Il attaque", "Il conçoit les défenses d'un système", "Il vend des PC", "Rien"], bonne: 1,
      explication: "L'architecte conçoit les protections, comme les plans d'une forteresse." },
    { q: "La 'security by design' signifie...", choix: ["Ajouter la sécurité à la fin", "Penser la sécurité dès le début du projet", "Ne pas sécuriser", "Faire joli"], bonne: 1,
      explication: "La sécurité doit être prévue dès la conception, pas rajoutée après." },
    { q: "La défense en profondeur, c'est...", choix: ["Une seule super protection", "Empiler plusieurs protections", "Aucune protection", "Un virus"], bonne: 1,
      explication: "On empile plusieurs couches : si une tombe, les autres tiennent." },
    { q: "Le principe du moindre privilège signifie...", choix: ["Tout le monde est admin", "Chacun n'a que les droits nécessaires", "Personne n'a de droits", "On donne tout à tout le monde"], bonne: 1,
      explication: "On limite les droits au strict nécessaire pour réduire les dégâts." },
    { q: "Le 'Zero Trust' signifie...", choix: ["Faire confiance à tout le monde", "Ne faire confiance à personne par défaut, toujours vérifier", "Zéro ordinateur", "Zéro mot de passe"], bonne: 1,
      explication: "Zero Trust = vérifier à chaque accès, même en interne." },
    { q: "À quoi sert la segmentation du réseau ?", choix: ["À ralentir internet", "À empêcher un virus de se propager partout", "À décorer", "À rien"], bonne: 1,
      explication: "Cloisonner limite la propagation d'une attaque." },
    { q: "Que signifie le cadenas 🔒 / 'https' dans le navigateur ?", choix: ["Le site est gratuit", "La connexion est chiffrée (sécurisée)", "Le site est rapide", "Le site est officiel à coup sûr"], bonne: 1,
      explication: "Https = connexion chiffrée. (Attention : ça ne garantit pas que le site est honnête.)" },
    { q: "Que dit la règle 3-2-1 des sauvegardes ?", choix: ["3 mots de passe", "3 copies, sur 2 supports, dont 1 ailleurs", "1 seule copie suffit", "321 virus"], bonne: 1,
      explication: "3 copies, sur 2 supports différents, dont 1 hors site." }
  ],
  labs: ["archi-defense"]
}

];
