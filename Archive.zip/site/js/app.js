/* ============================================================
   APPLICATION — routeur simple (hash) + rendu des vues
   ============================================================ */

const app = document.getElementById("app");
Progress.load();

/* ----------------- Utilitaires ----------------- */
function h(html){ return html; }
function go(hash){ location.hash = hash; }
window.addEventListener("hashchange", render);
window.addEventListener("DOMContentLoaded", () => { buildSidebar(); render(); updateHeader(); });

function updateHeader() {
  const nom = Progress.data.nom;
  document.getElementById("greet").textContent = nom ? `👋 Salut ${nom} !` : "Bienvenue 👋";
  const pct = Progress.globalPercent();
  document.getElementById("global-bar").style.width = pct + "%";
  document.getElementById("global-pct").textContent = pct + "%";
}

/* ----------------- Barre latérale ----------------- */
function buildSidebar() {
  const nav = document.getElementById("sidenav");
  nav.innerHTML = `
    <a class="nav-item" href="#/">🏠 Accueil</a>
    <div class="nav-sep">PARCOURS</div>
    ${MODULES.map(m=>`
      <a class="nav-item" href="#/module/${m.id}" data-mid="${m.id}">
        <span class="nav-ic" style="background:${m.couleur}22;color:${m.couleur}">${m.icone}</span>
        <span class="nav-label">${m.titre}</span>
        <span class="nav-check" id="navcheck-${m.id}"></span>
      </a>`).join("")}
    <div class="nav-sep">MOI</div>
    <a class="nav-item" href="#/progression">📊 Ma progression</a>
    <a class="nav-item" href="#/diplome">🎓 Mon diplôme</a>
    <a class="nav-item" href="#/aide">❓ Aide & guide</a>`;
  refreshSidebarChecks();
}
function refreshSidebarChecks() {
  MODULES.forEach(m=>{
    const el = document.getElementById(`navcheck-${m.id}`);
    if (el) el.textContent = Progress.moduleDone(m) ? "✅" : "";
  });
}
function highlightNav() {
  document.querySelectorAll(".nav-item").forEach(a=>{
    a.classList.toggle("active", a.getAttribute("href") === location.hash || (location.hash===""&&a.getAttribute("href")==="#/"));
  });
}

/* ----------------- Routeur ----------------- */
function render() {
  const hash = location.hash || "#/";
  const parts = hash.replace(/^#\//,"").split("/");
  window.scrollTo(0,0);
  if (parts[0] === "" ) return viewHome();
  if (parts[0] === "module") return viewModule(parts[1]);
  if (parts[0] === "lecon")  return viewLecon(parts[1], +parts[2]);
  if (parts[0] === "qcm")    return viewQcm(parts[1]);
  if (parts[0] === "lab")    return viewLab(parts[1], parts[2]);
  if (parts[0] === "progression") return viewProgress();
  if (parts[0] === "diplome") return viewDiplome();
  if (parts[0] === "aide")   return viewAide();
  viewHome();
  highlightNav();
}

/* ----------------- Vue : Accueil ----------------- */
function viewHome() {
  const nom = Progress.data.nom;
  app.innerHTML = `
    ${!nom ? `
    <div class="welcome-box">
      <h2>🔐 Bienvenue sur ta plateforme de cybersécurité !</h2>
      <p>Pendant ces 4 jours, tu vas découvrir les métiers de la cybersécurité à travers des <strong>cours</strong>,
         des <strong>mini-labs</strong> (de la pratique !) et des <strong>quiz</strong>. Pour commencer, dis-nous ton prénom :</p>
      <div class="name-row">
        <input id="name-in" class="lab-input" placeholder="Ton prénom..." maxlength="20" autocomplete="off">
        <button class="btn btn-primary" id="name-btn">C'est parti ! →</button>
      </div>
    </div>` : `
    <div class="hero">
      <h2>Ton parcours fil rouge 🧵</h2>
      <p>Choisis un parcours ci-dessous. L'idéal : suis-les dans l'ordre, du haut vers le bas.
         Fais les cours, puis les mini-labs, puis le quiz pour valider chaque thème.</p>
    </div>`}

    <div class="module-grid">
      ${MODULES.map((m,i)=>{
        const done = Progress.moduleDone(m);
        const q = Progress.getQcm(m.id);
        const labCount = (m.labs||[]).length;
        const labOk = (m.labs||[]).filter(id=>Progress.labDone(id)).length;
        return `
        <a class="module-card ${done?'done':''}" href="#/module/${m.id}" style="--c:${m.couleur}">
          <div class="mc-top">
            <div class="mc-icon">${m.icone}</div>
            ${done?'<div class="mc-badge">✅ Terminé</div>':`<div class="mc-num">${i===0?'Démarre ici':'Parcours '+(i+1)}</div>`}
          </div>
          <h3>${m.titre}</h3>
          <p>${m.resume}</p>
          <div class="mc-meta">
            <span>📖 ${m.lecons.length} leçons</span>
            ${labCount?`<span>🧪 ${labOk}/${labCount} labs</span>`:``}
            <span>📝 QCM ${q?q.score+'/'+q.total:''}</span>
          </div>
        </a>`;
      }).join("")}
    </div>`;

  if (!nom) {
    const inp = document.getElementById("name-in");
    const set = ()=>{ const v=inp.value.trim(); if(v){ Progress.setNom(v); updateHeader(); render(); } };
    document.getElementById("name-btn").addEventListener("click", set);
    inp.addEventListener("keydown", e=>{ if(e.key==="Enter") set(); });
    inp.focus();
  }
  highlightNav();
}

/* ----------------- Vue : Module ----------------- */
function viewModule(mid) {
  const m = MODULES.find(x=>x.id===mid);
  if (!m) return viewHome();
  app.innerHTML = `
    <div class="crumb"><a href="#/">Accueil</a> / ${m.titre}</div>
    <div class="module-header" style="--c:${m.couleur}">
      <div class="mh-icon">${m.icone}</div>
      <div><h2>${m.titre}</h2><p>${m.resume} · ⏱️ ${m.duree}</p></div>
    </div>

    <h3 class="section-title">📖 Les cours</h3>
    <div class="list">
      ${m.lecons.map((l,i)=>`
        <a class="list-item" href="#/lecon/${m.id}/${i}">
          <span class="li-num">${i+1}</span>
          <span class="li-title">${l.titre}</span>
          <span class="li-state">${Progress.leconDone(m.id,i)?'✅':'▶️'}</span>
        </a>`).join("")}
    </div>

    ${(m.labs||[]).length ? `
      <h3 class="section-title">🧪 Les mini-labs (pratique !)</h3>
      <div class="list">
        ${m.labs.map(id=>{ const lab=LABS[id]; if(!lab) return "";
          return `<a class="list-item" href="#/lab/${m.id}/${id}">
            <span class="li-num">${lab.icone}</span>
            <span class="li-title">${lab.titre}</span>
            <span class="li-state">${Progress.labDone(id)?'🏆':'▶️'}</span>
          </a>`;}).join("")}
      </div>` : ``}

    <h3 class="section-title">📝 Le quiz</h3>
    <div class="list">
      <a class="list-item" href="#/qcm/${m.id}">
        <span class="li-num">?</span>
        <span class="li-title">QCM — ${m.qcm.length} questions</span>
        <span class="li-state">${Progress.getQcm(m.id)?Progress.getQcm(m.id).score+'/'+Progress.getQcm(m.id).total:'▶️'}</span>
      </a>
    </div>`;
  highlightNav();
}

/* ----------------- Vue : Leçon ----------------- */
function viewLecon(mid, idx) {
  const m = MODULES.find(x=>x.id===mid); if(!m) return viewHome();
  const l = m.lecons[idx]; if(!l) return viewModule(mid);
  Progress.markLecon(mid, idx);
  refreshSidebarChecks(); updateHeader();
  const prev = idx>0 ? `#/lecon/${mid}/${idx-1}` : `#/module/${mid}`;
  const next = idx<m.lecons.length-1 ? `#/lecon/${mid}/${idx+1}` : `#/module/${mid}`;
  const nextLabel = idx<m.lecons.length-1 ? "Leçon suivante →" : "Retour au parcours →";
  app.innerHTML = `
    <div class="crumb"><a href="#/">Accueil</a> / <a href="#/module/${mid}">${m.titre}</a> / Leçon ${idx+1}</div>
    <article class="lesson" style="--c:${m.couleur}">
      <div class="lesson-tag">${m.icone} ${m.titre} — Leçon ${idx+1}/${m.lecons.length}</div>
      <h2>${l.titre}</h2>
      <div class="lesson-body">${l.html}</div>
    </article>
    <div class="pager">
      <a class="btn btn-ghost" href="${prev}">← Précédent</a>
      <a class="btn btn-primary" href="${next}">${nextLabel}</a>
    </div>`;
  highlightNav();
}

/* ----------------- Vue : Lab ----------------- */
function viewLab(mid, labId) {
  const m = MODULES.find(x=>x.id===mid);
  const lab = LABS[labId];
  if (!lab) return viewModule(mid);
  app.innerHTML = `
    <div class="crumb"><a href="#/">Accueil</a> / <a href="#/module/${mid}">${m?m.titre:''}</a> / Lab</div>
    <div class="lab-header">
      <div class="lab-ic">${lab.icone}</div>
      <div><h2>${lab.titre}</h2><p>${lab.intro}</p></div>
    </div>
    <div id="lab-root" class="lab-root"></div>
    <div class="pager">
      <a class="btn btn-ghost" href="#/module/${mid}">← Retour au parcours</a>
    </div>`;
  const root = document.getElementById("lab-root");
  lab.render(root, () => {
    if (!Progress.labDone(labId)) {
      Progress.markLab(labId);
      refreshSidebarChecks(); updateHeader();
      toast("🏆 Lab validé ! Bravo.");
    }
  });
  highlightNav();
}

/* ----------------- Vue : QCM ----------------- */
function viewQcm(mid) {
  const m = MODULES.find(x=>x.id===mid); if(!m) return viewHome();
  let answers = new Array(m.qcm.length).fill(null);
  app.innerHTML = `
    <div class="crumb"><a href="#/">Accueil</a> / <a href="#/module/${mid}">${m.titre}</a> / QCM</div>
    <div class="qcm-head" style="--c:${m.couleur}"><h2>📝 QCM — ${m.titre}</h2>
      <p>Réponds aux ${m.qcm.length} questions puis valide. Il faut ${Math.ceil(m.qcm.length*0.6)}/${m.qcm.length} pour réussir.</p></div>
    <form id="qcm-form">
      ${m.qcm.map((q,i)=>`
        <div class="qcm-q" data-qi="${i}">
          <p class="qcm-question">${i+1}. ${q.q}</p>
          ${q.choix.map((c,j)=>`
            <label class="qcm-opt"><input type="radio" name="q${i}" value="${j}"><span>${c}</span></label>`).join("")}
          <div class="qcm-expl" id="expl-${i}"></div>
        </div>`).join("")}
      <button type="button" class="btn btn-primary btn-big" id="qcm-submit">Valider mes réponses ✓</button>
    </form>
    <div id="qcm-result"></div>`;

  document.getElementById("qcm-submit").addEventListener("click", () => {
    let score = 0, missing = false;
    m.qcm.forEach((q,i)=>{
      const sel = app.querySelector(`input[name="q${i}"]:checked`);
      const box = app.querySelector(`.qcm-q[data-qi="${i}"]`);
      const expl = document.getElementById(`expl-${i}`);
      box.querySelectorAll(".qcm-opt").forEach(o=>o.classList.remove("good","bad"));
      if (!sel) { missing = true; box.classList.add("shake"); setTimeout(()=>box.classList.remove("shake"),500); return; }
      const j = +sel.value;
      const opts = box.querySelectorAll(".qcm-opt");
      opts[q.bonne].classList.add("good");
      if (j === q.bonne) score++;
      else opts[j].classList.add("bad");
      expl.innerHTML = `💡 ${q.explication}`;
      expl.classList.add("show");
    });
    if (missing) { toast("⚠️ Réponds à toutes les questions."); return; }
    Progress.setQcm(mid, score, m.qcm.length);
    refreshSidebarChecks(); updateHeader();
    const pass = score >= Math.ceil(m.qcm.length*0.6);
    const res = document.getElementById("qcm-result");
    res.innerHTML = `<div class="lab-result ${pass?'success':'partial'}">
      ${pass?'🎉':'📚'} Score : <strong>${score}/${m.qcm.length}</strong>. ${pass?'Bravo, QCM réussi !':'Relis le cours et retente quand tu veux.'}
      <div class="lab-btn-row" style="margin-top:12px">
        <a class="btn btn-ghost" href="#/module/${mid}">← Retour au parcours</a>
        ${!pass?'<button class="btn btn-primary" id="qcm-retry">↺ Recommencer</button>':''}
      </div></div>`;
    res.scrollIntoView({behavior:"smooth"});
    if (!pass) document.getElementById("qcm-retry").addEventListener("click", ()=>viewQcm(mid));
    document.getElementById("qcm-submit").disabled = true;
  });
  highlightNav();
}

/* ----------------- Vue : Progression ----------------- */
function viewProgress() {
  const pct = Progress.globalPercent();
  app.innerHTML = `
    <div class="crumb"><a href="#/">Accueil</a> / Ma progression</div>
    <h2>📊 Ma progression</h2>
    <div class="big-progress">
      <div class="bp-circle" style="--p:${pct}">
        <span>${pct}%</span>
      </div>
      <div class="bp-text">
        <p>Élève : <strong>${Progress.data.nom||'—'}</strong></p>
        <p>Continue comme ça ! Chaque cours, lab et quiz validé fait monter la jauge.</p>
      </div>
    </div>
    <table class="table progress-table">
      <tr><th>Parcours</th><th>Cours</th><th>Labs</th><th>QCM</th><th>État</th></tr>
      ${MODULES.map(m=>{
        const lecDone = m.lecons.filter((_,i)=>Progress.leconDone(m.id,i)).length;
        const labTot = (m.labs||[]).length;
        const labOk = (m.labs||[]).filter(id=>Progress.labDone(id)).length;
        const q = Progress.getQcm(m.id);
        return `<tr>
          <td>${m.icone} ${m.titre}</td>
          <td>${lecDone}/${m.lecons.length}</td>
          <td>${labTot?labOk+'/'+labTot:'—'}</td>
          <td>${q?q.score+'/'+q.total:'—'}</td>
          <td>${Progress.moduleDone(m)?'✅':'⏳'}</td>
        </tr>`;
      }).join("")}
    </table>
    <div class="lab-btn-row" style="margin-top:20px">
      <button class="btn btn-primary" id="exp-btn">📄 Exporter mes résultats</button>
      <button class="btn btn-ghost" id="reset-btn">🗑️ Tout réinitialiser</button>
    </div>
    <pre id="exp-out" class="export-out" style="display:none"></pre>`;
  document.getElementById("exp-btn").addEventListener("click", ()=>{
    const out = document.getElementById("exp-out");
    out.style.display = "block";
    out.textContent = Progress.exportText();
    const blob = new Blob([Progress.exportText()], {type:"text/plain"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `resultats_${(Progress.data.nom||'eleve')}.txt`; a.click();
    URL.revokeObjectURL(url);
    toast("📄 Résultats exportés (fichier téléchargé).");
  });
  document.getElementById("reset-btn").addEventListener("click", ()=>{
    if (confirm("Effacer toute ta progression ? (ton prénom est conservé)")) {
      Progress.reset(); refreshSidebarChecks(); updateHeader(); viewProgress();
      toast("Progression réinitialisée.");
    }
  });
  highlightNav();
}

/* ----------------- Vue : Diplôme ----------------- */
function nbModulesDone(){ return MODULES.filter(m=>Progress.moduleDone(m)).length; }
function totalQcmScore(){
  let s=0,t=0;
  MODULES.forEach(m=>{ const q=Progress.getQcm(m.id); if(q){s+=q.score;t+=q.total;} });
  return {s,t};
}
function viewDiplome() {
  const done = nbModulesDone();
  const total = MODULES.length;
  const eligible = done === total;
  const nom = Progress.data.nom || "";
  const score = totalQcmScore();
  const dateStr = new Date().toLocaleDateString("fr-FR", {day:"numeric",month:"long",year:"numeric"});

  if (!eligible) {
    app.innerHTML = `
      <div class="crumb"><a href="#/">Accueil</a> / Mon diplôme</div>
      <h2>🎓 Mon diplôme</h2>
      <div class="diploma-lock">
        <div class="dl-ic">🔒</div>
        <h3>Ton diplôme t'attend !</h3>
        <p>Pour le débloquer, tu dois <strong>terminer les ${total} parcours</strong> (cours + mini-labs + QCM de chacun).</p>
        <div class="dl-progress">
          <div class="dl-count">${done} / ${total}</div>
          <div class="gp-track" style="width:220px"><div class="gp-fill" style="width:${Math.round(done/total*100)}%"></div></div>
          <div class="dl-label">parcours terminés</div>
        </div>
        <div class="dl-list">
          ${MODULES.map(m=>`<div class="dl-row"><span>${Progress.moduleDone(m)?'✅':'⬜'}</span> ${m.icone} ${m.titre}
            ${!Progress.moduleDone(m)?`<a class="dl-go" href="#/module/${m.id}">continuer →</a>`:''}</div>`).join("")}
        </div>
      </div>`;
    highlightNav();
    return;
  }

  const mention = score.t ? Math.round(score.s/score.t*100) : 100;
  let mentionTxt = "Très bien";
  if (mention >= 90) mentionTxt = "Félicitations du jury";
  else if (mention >= 75) mentionTxt = "Très bien";
  else mentionTxt = "Bien";

  app.innerHTML = `
    <div class="crumb no-print"><a href="#/">Accueil</a> / Mon diplôme</div>
    <div class="diploma-actions no-print">
      <div class="da-congrats">🎉 Bravo ${nom} ! Tu as terminé tout le parcours. Voici ton diplôme.</div>
      <div class="lab-btn-row">
        <button class="btn btn-primary" id="print-dip">🖨️ Imprimer / Enregistrer en PDF</button>
      </div>
      <p class="da-hint">Astuce : dans la fenêtre d'impression, choisis « Enregistrer au format PDF » comme imprimante pour garder ton diplôme.</p>
    </div>

    <div class="diploma" id="diploma">
      <div class="diploma-inner">
        <div class="dip-logo">
          <img src="assets/logo-apixit-bechtle.png" alt="Apixit x Bechtle Group">
        </div>
        <div class="dip-kicker">Stage d'observation · Découverte des métiers de la cybersécurité</div>
        <h1 class="dip-title">Diplôme de Cyber-Découverte</h1>
        <div class="dip-sub">décerné à</div>
        <div class="dip-name">${nom ? nom.replace(/</g,'') : "l'élève"}</div>
        <p class="dip-text">
          pour avoir suivi avec succès l'ensemble du programme de découverte de la cybersécurité :
          gouvernance, OSINT, test d'intrusion, investigation numérique (forensic),
          analyse SOC et architecture de sécurité — à travers des cours, des mini-labs pratiques et des quiz.
        </p>
        <div class="dip-stats">
          <div class="dip-stat"><strong>${total}</strong><span>parcours validés</span></div>
          <div class="dip-stat"><strong>${score.s}/${score.t}</strong><span>bonnes réponses aux QCM</span></div>
          <div class="dip-stat"><strong>${mentionTxt}</strong><span>mention</span></div>
        </div>
        <div class="dip-foot">
          <div class="dip-sign">
            <div class="dip-line"></div>
            <span>L'élève</span>
          </div>
          <div class="dip-seal">
            <div class="dip-seal-circle">🛡️</div>
          </div>
          <div class="dip-sign">
            <div class="dip-line"></div>
            <span>Le tuteur de stage</span>
          </div>
        </div>
        <div class="dip-date">Délivré le ${dateStr}</div>
        <div class="dip-brand">Programme encadré par <strong>Apixit</strong> — groupe <strong>Bechtle</strong></div>
      </div>
    </div>`;
  document.getElementById("print-dip").addEventListener("click", ()=>window.print());
  highlightNav();
}

/* ----------------- Vue : Aide ----------------- */
function viewAide() {
  app.innerHTML = `
    <div class="crumb"><a href="#/">Accueil</a> / Aide</div>
    <h2>❓ Comment utiliser la plateforme ?</h2>
    <div class="help-steps">
      <div class="help-step"><span>1</span><div><strong>Choisis un parcours</strong> depuis l'accueil ou le menu de gauche. Commence par « Introduction & Gouvernance ».</div></div>
      <div class="help-step"><span>2</span><div><strong>Lis les cours</strong> dans l'ordre. Chaque leçon est courte et illustrée.</div></div>
      <div class="help-step"><span>3</span><div><strong>Fais les mini-labs</strong> : c'est la partie pratique, interactive. Le plus amusant !</div></div>
      <div class="help-step"><span>4</span><div><strong>Valide le QCM</strong> pour tester tes connaissances et terminer le parcours (✅).</div></div>
      <div class="help-step"><span>5</span><div><strong>Suis ta progression</strong> dans l'onglet « Ma progression », et exporte tes résultats pour les montrer à ton tuteur.</div></div>
    </div>
    <div class="callout callout-info" style="margin-top:20px">
      <strong>Note importante :</strong> tout se passe dans ton navigateur. Rien n'est envoyé sur internet,
      aucun vrai système n'est attaqué. C'est un terrain d'entraînement 100% sûr et pédagogique.
    </div>
    <div class="callout callout-tip" style="margin-top:14px">
      <strong>Ta progression est enregistrée dans ce navigateur.</strong> Utilise le même ordinateur et le même navigateur
      tout au long de la semaine pour la retrouver.
    </div>
    <h3 class="section-title">🎯 Idées de projet fil rouge (4 jours)</h3>
    <ul class="help-plan">
      <li><strong>Jour 1 :</strong> Introduction & Gouvernance + OSINT (découverte, vocabulaire, 1ers labs).</li>
      <li><strong>Jour 2 :</strong> Pentest + hygiène des mots de passe + repérage du phishing.</li>
      <li><strong>Jour 3 :</strong> Forensic (analyse de logs, décodage) + Analyste SOC (triage d'alertes).</li>
      <li><strong>Jour 4 :</strong> Architecte cyber + révision + présentation orale de ce qu'elle a appris.</li>
    </ul>`;
  highlightNav();
}

/* ----------------- Toast ----------------- */
let toastT;
function toast(msg) {
  let t = document.getElementById("toast");
  if (!t) { t = document.createElement("div"); t.id="toast"; document.body.appendChild(t); }
  t.textContent = msg; t.classList.add("show");
  clearTimeout(toastT);
  toastT = setTimeout(()=>t.classList.remove("show"), 2600);
}
