/* ============================================================
   MINI-LABS INTERACTIFS
   Chaque lab : { titre, icone, intro, render(root, done) }
   `done()` est appelé quand l'élève réussit le lab (progression).
   Tout est en JavaScript côté navigateur : rien n'est envoyé,
   aucun système réel n'est attaqué. 100% sûr et pédagogique.
   ============================================================ */

const LABS = {

/* ---------- OSINT : Détective métadonnées ---------- */
"osint-metadata": {
  titre: "Détective métadonnées",
  icone: "🖼️",
  intro: "On a retrouvé une photo publiée par un inconnu. Lis les métadonnées (EXIF) cachées dans le fichier et réponds à l'enquête.",
  render(root, done) {
    root.innerHTML = `
      <div class="lab-panel">
        <div class="lab-screen">
          <div class="exif-header">📄 photo_vacances.jpg — Métadonnées EXIF</div>
          <table class="exif-table">
            <tr><td>Appareil</td><td>iPhone 14 Pro</td></tr>
            <tr><td>Date de prise</td><td>2026-07-14  18:32:05</td></tr>
            <tr><td>Logiciel</td><td>iOS 18.2</td></tr>
            <tr><td>GPS Latitude</td><td>48.8584° N</td></tr>
            <tr><td>GPS Longitude</td><td>2.2945° E</td></tr>
            <tr><td>Altitude</td><td>120 m</td></tr>
            <tr><td>Flash</td><td>Désactivé</td></tr>
          </table>
        </div>
        <div class="lab-questions" id="q-metadata"></div>
      </div>`;
    const questions = [
      { q: "Avec quel type d'appareil la photo a-t-elle été prise ?", choix:["Un appareil photo Canon","Un iPhone","Un drone","On ne peut pas savoir"], bonne:1 },
      { q: "À quelle heure la photo a-t-elle été prise ?", choix:["3h du matin","Midi","18h32","Minuit"], bonne:2 },
      { q: "Ces coordonnées GPS (48.85 N, 2.29 E) correspondent à un lieu très connu. Lequel, à ton avis ?", choix:["La Tour Eiffel (Paris)","New York","Tokyo","Le pôle Nord"], bonne:0 },
      { q: "Quelle leçon en tirer pour ta propre sécurité ?", choix:["Publier plus de photos","Désactiver la géolocalisation de mes photos","Donner mon adresse","Rien à faire"], bonne:1 }
    ];
    renderQuiz(document.getElementById("q-metadata"), questions, done);
  }
},

/* ---------- OSINT : Bon dork, bonne recherche ---------- */
"osint-dork": {
  titre: "Le bon dork",
  icone: "🔎",
  intro: "Un 'Google dork' est une recherche avancée. Associe chaque objectif à la bonne commande.",
  render(root, done) {
    root.innerHTML = `<div class="lab-questions" id="q-dork"></div>`;
    const questions = [
      { q: "Je veux chercher UNIQUEMENT sur le site education.gouv.fr. J'utilise...", choix:["site:education.gouv.fr","filetype:pdf","intitle:","@education"], bonne:0 },
      { q: "Je veux trouver seulement des fichiers PDF. J'utilise...", choix:["site:","filetype:pdf","\"\"","intitle:"], bonne:1 },
      { q: "Je veux l'expression EXACTE « collège Jean Moulin ». J'utilise...", choix:["collège Jean Moulin","site:college","\"collège Jean Moulin\"","filetype:college"], bonne:2 },
      { q: "Je veux un mot présent dans le TITRE de la page. J'utilise...", choix:["intitle:rapport","filetype:rapport","site:rapport","rapport!"], bonne:0 }
    ];
    renderQuiz(document.getElementById("q-dork"), questions, done);
  }
},

/* ---------- PENTEST : Testeur de mot de passe ---------- */
"pentest-password": {
  titre: "Testeur de mot de passe",
  icone: "🔑",
  intro: "Tape un mot de passe et observe sa force. Objectif : atteindre le niveau « SOLIDE » pour valider le lab (on n'enregistre rien, tape ce que tu veux).",
  render(root, done) {
    root.innerHTML = `
      <div class="lab-panel">
        <label class="lab-label">Teste un mot de passe :</label>
        <input type="text" id="pw-input" class="lab-input" placeholder="Tape ici..." autocomplete="off">
        <div class="pw-meter"><div id="pw-bar" class="pw-bar"></div></div>
        <div id="pw-verdict" class="pw-verdict">—</div>
        <ul id="pw-checks" class="pw-checks">
          <li data-k="len">Au moins 12 caractères</li>
          <li data-k="maj">Une majuscule</li>
          <li data-k="min">Une minuscule</li>
          <li data-k="num">Un chiffre</li>
          <li data-k="sym">Un symbole (!@#...)</li>
          <li data-k="common">N'est pas un mot de passe courant</li>
        </ul>
        <div class="callout callout-info" style="margin-top:14px">
          💡 Astuce : essaie une phrase de passe comme <code>MonChat@Mange3Croquettes!</code>
        </div>
      </div>`;
    const commons = ["123456","password","azerty","motdepasse","qwerty","111111","000000","admin","soleil","doudou","123456789","mot de passe"];
    const input = document.getElementById("pw-input");
    const bar = document.getElementById("pw-bar");
    const verdict = document.getElementById("pw-verdict");
    let validated = false;
    input.addEventListener("input", () => {
      const v = input.value;
      const checks = {
        len: v.length >= 12,
        maj: /[A-Z]/.test(v),
        min: /[a-z]/.test(v),
        num: /[0-9]/.test(v),
        sym: /[^A-Za-z0-9]/.test(v),
        common: v.length > 0 && !commons.includes(v.toLowerCase())
      };
      let score = 0;
      Object.keys(checks).forEach(k => {
        const li = root.querySelector(`[data-k="${k}"]`);
        if (checks[k]) { li.classList.add("ok"); score++; } else { li.classList.remove("ok"); }
      });
      const pct = Math.round((score/6)*100);
      bar.style.width = pct + "%";
      let label, color;
      if (v.length === 0) { label="—"; color="#334155"; bar.style.width="0%"; }
      else if (score <= 2) { label="❌ TRÈS FAIBLE"; color="#ef4444"; }
      else if (score <= 4) { label="⚠️ MOYEN"; color="#f59e0b"; }
      else if (score === 5) { label="🙂 BON"; color="#eab308"; }
      else { label="✅ SOLIDE"; color="#22c55e"; }
      bar.style.background = color;
      verdict.textContent = label;
      verdict.style.color = color;
      if (score === 6 && !validated) { validated = true; done(); markLabSuccess(root); }
    });
  }
},

/* ---------- PENTEST : Repère le phishing ---------- */
"pentest-phishing": {
  titre: "Repère le phishing",
  icone: "🎣",
  intro: "Voici de vrais messages reçus par email. Pour chacun, dis s'il s'agit d'un piège (phishing) ou d'un message légitime. Observe les indices !",
  render(root, done) {
    const mails = [
      { from:"securite@bnaque-populaire.com", sujet:"URGENT : votre compte sera bloqué !!!",
        corps:"Cher client, cliquez vite sur ce lien pour vérifier vos identifiants sinon votre compte sera fermé dans 24h. http://bnaque-secure-login.ru",
        phishing:true, indice:"L'adresse est bizarre (bnaque mal écrit, .ru), ça menace, ça presse, et ça demande tes identifiants : 3 signaux d'alerte !" },
      { from:"prof.martin@mon-college.fr", sujet:"Rappel : sortie scolaire vendredi",
        corps:"Bonjour, n'oubliez pas l'autorisation signée pour la sortie de vendredi. Bonne journée.",
        phishing:false, indice:"Adresse cohérente, pas de lien suspect, pas d'urgence ni de demande de mot de passe. Légitime." },
      { from:"cadeau@amaz0n-gift.net", sujet:"Vous avez gagné un iPhone 🎁",
        corps:"Félicitations ! Vous êtes le 1 000 000e visiteur. Entrez votre numéro de carte pour recevoir votre iPhone gratuit.",
        phishing:true, indice:"Trop beau pour être vrai, 'amaz0n' avec un zéro, et ça demande ta carte bancaire. Piège évident !" },
      { from:"no-reply@netflix.com", sujet:"Votre facture de novembre",
        corps:"Bonjour, votre abonnement a été renouvelé. Consultez votre facture dans votre espace personnel habituel.",
        phishing:false, indice:"Pas de lien douteux, pas de demande d'identifiants, ton neutre. Légitime." }
    ];
    let idx = 0, ok = 0;
    root.innerHTML = `<div id="mail-zone"></div>`;
    const zone = document.getElementById("mail-zone");
    function show() {
      if (idx >= mails.length) {
        zone.innerHTML = `<div class="lab-result success">🎉 Terminé ! Tu as bien analysé ${ok}/${mails.length} messages.<br>Les signaux du phishing : urgence, menace, fautes, adresse bizarre, demande d'identifiants ou d'argent.</div>`;
        if (ok >= 3) done();
        return;
      }
      const m = mails[idx];
      zone.innerHTML = `
        <div class="mail-card">
          <div class="mail-head">
            <div><strong>De :</strong> <span class="mail-from">${m.from}</span></div>
            <div><strong>Objet :</strong> ${m.sujet}</div>
          </div>
          <div class="mail-body">${m.corps}</div>
        </div>
        <p class="lab-ask">Ce message est-il un piège (phishing) ?</p>
        <div class="lab-btn-row">
          <button class="btn btn-danger" id="b-phish">🎣 PHISHING</button>
          <button class="btn btn-ok" id="b-legit">✅ LÉGITIME</button>
        </div>
        <div id="mail-feedback"></div>`;
      const fb = document.getElementById("mail-feedback");
      function answer(choicePhish) {
        const correct = choicePhish === m.phishing;
        if (correct) ok++;
        fb.innerHTML = `<div class="lab-feedback ${correct?'good':'bad'}">
          ${correct ? "✔️ Bien vu !" : "✘ Raté."} ${m.indice}
          <div style="margin-top:10px"><button class="btn btn-primary" id="next-mail">Suivant →</button></div></div>`;
        document.getElementById("b-phish").disabled = true;
        document.getElementById("b-legit").disabled = true;
        document.getElementById("next-mail").addEventListener("click", () => { idx++; show(); });
      }
      document.getElementById("b-phish").addEventListener("click", () => answer(true));
      document.getElementById("b-legit").addEventListener("click", () => answer(false));
    }
    show();
  }
},

/* ---------- FORENSIC : Analyse de logs ---------- */
"forensic-logs": {
  titre: "Analyse de logs",
  icone: "📜",
  intro: "Voici l'extrait d'un journal de connexions d'un serveur. Un intrus s'est glissé parmi les connexions normales. Sauras-tu le repérer ?",
  render(root, done) {
    const logs = [
      "08:12:44  LOGIN  user=sophie   ip=192.168.1.10   statut=OK",
      "08:31:09  LOGIN  user=karim    ip=192.168.1.14   statut=OK",
      "09:05:51  LOGIN  user=sophie   ip=192.168.1.10   statut=OK",
      "03:14:07  LOGIN  user=admin    ip=185.23.44.9    statut=ÉCHEC",
      "03:14:08  LOGIN  user=admin    ip=185.23.44.9    statut=ÉCHEC",
      "03:14:09  LOGIN  user=admin    ip=185.23.44.9    statut=ÉCHEC",
      "03:14:12  LOGIN  user=admin    ip=185.23.44.9    statut=OK",
      "09:47:22  LOGIN  user=lea      ip=192.168.1.21   statut=OK"
    ];
    root.innerHTML = `
      <div class="lab-panel">
        <p class="lab-ask">Clique sur la ligne la plus SUSPECTE (celle qui prouve que l'intrus a réussi à entrer) :</p>
        <div class="log-viewer" id="logv">
          ${logs.map((l,i)=>`<div class="log-line" data-i="${i}">${l}</div>`).join("")}
        </div>
        <div id="log-feedback"></div>
      </div>`;
    const fb = document.getElementById("log-feedback");
    root.querySelectorAll(".log-line").forEach(line => {
      line.addEventListener("click", () => {
        const i = +line.dataset.i;
        root.querySelectorAll(".log-line").forEach(l=>l.classList.remove("sel"));
        line.classList.add("sel");
        if (i === 6) {
          line.classList.add("hit");
          fb.innerHTML = `<div class="lab-feedback good">✔️ Parfait ! À 03:14, un inconnu (ip 185.23.44.9) a essayé le compte « admin » plusieurs fois (ÉCHEC, ÉCHEC, ÉCHEC) puis a RÉUSSI (OK) à 03:14:12. C'est une <strong>attaque par force brute réussie</strong> en pleine nuit. L'intrus est entré !</div>`;
          done();
        } else {
          fb.innerHTML = `<div class="lab-feedback bad">✘ Regarde mieux : cherche une heure anormale (la nuit), une adresse IP inconnue, et surtout plusieurs ÉCHECS suivis d'un OK.</div>`;
        }
      });
    });
  }
},

/* ---------- FORENSIC : Décodeur ---------- */
"forensic-decoder": {
  titre: "Décodeur de messages",
  icone: "🧩",
  intro: "Les pirates cachent leurs messages. Utilise le décodeur Base64 pour lire le message secret, puis réponds.",
  render(root, done) {
    root.innerHTML = `
      <div class="lab-panel">
        <label class="lab-label">Colle un texte en Base64 et clique sur Décoder :</label>
        <input type="text" id="b64-in" class="lab-input" value="UmVuZGV6LXZvdXMgYSBtaW51aXQ=" autocomplete="off">
        <div class="lab-btn-row">
          <button class="btn btn-primary" id="b64-btn">🔓 Décoder</button>
        </div>
        <div class="decoder-out" id="b64-out">—</div>
        <hr class="lab-sep">
        <p class="lab-ask">Décode le message ci-dessus, puis réponds :</p>
        <div id="q-decoder"></div>
      </div>`;
    document.getElementById("b64-btn").addEventListener("click", () => {
      const out = document.getElementById("b64-out");
      try {
        const txt = decodeURIComponent(escape(window.atob(document.getElementById("b64-in").value.trim())));
        out.textContent = "💬 " + txt;
        out.classList.add("decoded");
      } catch(e) {
        out.textContent = "⚠️ Ce n'est pas du Base64 valide.";
        out.classList.remove("decoded");
      }
    });
    const questions = [
      { q: "Que dit le message secret décodé ?", choix:["Rendez-vous à midi","Rendez-vous à minuit","Bonjour tout le monde","Mot de passe oublié"], bonne:1 },
      { q: "Le Base64, est-ce un vrai moyen de garder un secret ?", choix:["Oui, c'est incassable","Non, tout le monde peut le décoder facilement","Oui, seuls les pirates savent","C'est un virus"], bonne:1 }
    ];
    renderQuiz(document.getElementById("q-decoder"), questions, done);
  }
},

/* ---------- SOC : Centre d'alertes (triage) ---------- */
"soc-triage": {
  titre: "Centre d'alertes",
  icone: "🚨",
  intro: "Tu es analyste SOC niveau 1. Des alertes arrivent. Pour chacune, décide : vraie menace ou fausse alerte ? Trie correctement au moins 4 alertes sur 5.",
  render(root, done) {
    const alerts = [
      { txt:"500 tentatives de connexion échouées en 1 minute depuis une IP inconnue à l'étranger.", menace:true,
        expl:"Beaucoup d'échecs très rapides = attaque par force brute. Vraie menace !" },
      { txt:"Un employé se connecte à 8h12 depuis son bureau habituel.", menace:false,
        expl:"Heure et lieu normaux : c'est une activité légitime. Faux positif." },
      { txt:"Un fichier nommé 'facture.pdf.exe' a été téléchargé et exécuté sur un poste.", menace:true,
        expl:"Une double extension .pdf.exe qui s'exécute = logiciel malveillant déguisé. Vraie menace !" },
      { txt:"La mise à jour automatique de l'antivirus s'est installée à 3h du matin.", menace:false,
        expl:"Les mises à jour planifiées la nuit sont normales. Faux positif." },
      { txt:"Un compte envoie 10 000 emails en 5 minutes vers l'extérieur.", menace:true,
        expl:"Envoi massif soudain = compte peut-être piraté (spam). Vraie menace !" }
    ];
    let idx = 0, ok = 0;
    root.innerHTML = `<div id="alert-zone"></div><div class="soc-counter">Alertes traitées : <span id="soc-n">0</span>/5 — Correctes : <span id="soc-ok">0</span></div>`;
    const zone = document.getElementById("alert-zone");
    function show() {
      if (idx >= alerts.length) {
        zone.innerHTML = `<div class="lab-result ${ok>=4?'success':'partial'}">
          ${ok>=4 ? "🎉 Excellent triage, analyste !" : "Pas mal, mais révise un peu."} Score : ${ok}/5.<br>
          Rappel : une vraie menace est souvent soudaine, massive, ou clairement anormale.</div>`;
        if (ok >= 4) done();
        else { zone.innerHTML += `<div class="lab-btn-row"><button class="btn btn-primary" id="retry">↺ Réessayer</button></div>`;
               document.getElementById("retry").addEventListener("click", ()=>{idx=0;ok=0;upd();show();}); }
        return;
      }
      const a = alerts[idx];
      zone.innerHTML = `
        <div class="alert-card">
          <div class="alert-icon">🔔</div>
          <div class="alert-txt">${a.txt}</div>
        </div>
        <div class="lab-btn-row">
          <button class="btn btn-danger" id="a-threat">🔴 VRAIE MENACE</button>
          <button class="btn btn-ok" id="a-false">🟡 FAUSSE ALERTE</button>
        </div>
        <div id="alert-fb"></div>`;
      function answer(isThreat) {
        const correct = isThreat === a.menace;
        if (correct) ok++;
        idx++;
        upd();
        const fb = document.getElementById("alert-fb");
        fb.innerHTML = `<div class="lab-feedback ${correct?'good':'bad'}">${correct?"✔️ Bon réflexe !":"✘ Pas tout à fait."} ${a.expl}
          <div style="margin-top:10px"><button class="btn btn-primary" id="a-next">Alerte suivante →</button></div></div>`;
        document.getElementById("a-threat").disabled = true;
        document.getElementById("a-false").disabled = true;
        document.getElementById("a-next").addEventListener("click", show);
      }
      document.getElementById("a-threat").addEventListener("click", ()=>answer(true));
      document.getElementById("a-false").addEventListener("click", ()=>answer(false));
    }
    function upd(){ document.getElementById("soc-n").textContent=idx; document.getElementById("soc-ok").textContent=ok; }
    show();
  }
},

/* ---------- FORENSIC : Chiffre de César ---------- */
"forensic-cesar": {
  titre: "Chiffre de César",
  icone: "🏛️",
  intro: "Un message a été chiffré avec le chiffre de César (chaque lettre décalée d'un même nombre). Fais glisser la molette de décalage pour retrouver le message en clair, puis réponds.",
  render(root, done) {
    const secret = "DWWDTXH D O DXEH"; // "ATTAQUE A L AUBE" décalé de 3
    root.innerHTML = `
      <div class="lab-panel">
        <label class="lab-label">Message chiffré intercepté :</label>
        <div class="decoder-out decoded" style="color:#f5dca6;border-color:#5b4414">🔒 ${secret}</div>
        <label class="lab-label" style="margin-top:16px">Décalage à essayer : <strong id="shift-val">0</strong></label>
        <input type="range" id="shift" min="0" max="25" value="0" class="cesar-slider">
        <label class="lab-label" style="margin-top:16px">Résultat déchiffré :</label>
        <div class="decoder-out" id="cesar-out" style="font-size:1.1rem;letter-spacing:1px">—</div>
        <div class="callout callout-info" style="margin-top:14px">
          💡 Indice : il n'y a que 25 décalages possibles. Essaie-les jusqu'à lire une vraie phrase en français !
        </div>
        <hr class="lab-sep">
        <p class="lab-ask">Une fois le message lisible, réponds :</p>
        <div id="q-cesar"></div>
      </div>`;
    const slider = document.getElementById("shift");
    const out = document.getElementById("cesar-out");
    const sval = document.getElementById("shift-val");
    function decode(txt, shift) {
      return txt.replace(/[A-Z]/g, c => String.fromCharCode((c.charCodeAt(0) - 65 - shift + 26) % 26 + 65));
    }
    function upd() {
      const s = +slider.value; sval.textContent = s;
      const res = decode(secret, s);
      out.textContent = "💬 " + res;
      if (s === 3) out.classList.add("decoded"); else out.classList.remove("decoded");
    }
    slider.addEventListener("input", upd); upd();
    const questions = [
      { q: "Avec le bon décalage, quel est le message en clair ?", choix:["ATTAQUE A L AUBE","RENDEZ VOUS A MIDI","BONJOUR LES AMIS","VICTOIRE TOTALE"], bonne:0 },
      { q: "Quel décalage fallait-il utiliser pour déchiffrer ?", choix:["3","7","13","25"], bonne:0 },
      { q: "Pourquoi le chiffre de César est-il facile à casser aujourd'hui ?", choix:["Il est illégal","Il n'y a que 25 décalages à essayer","Il est trop long","Il faut une clé USB"], bonne:1 }
    ];
    renderQuiz(document.getElementById("q-cesar"), questions, done);
  }
},

/* ---------- ARCHITECTE : Construis ta défense ---------- */
"archi-defense": {
  titre: "Construis ta défense",
  icone: "🏗️",
  intro: "Pour chaque menace, choisis la protection la plus adaptée. Objectif : au moins 4 bonnes associations sur 5.",
  render(root, done) {
    const cas = [
      { menace:"Un pirate essaie des milliers de mots de passe sur un compte.", bonne:"Double authentification (2FA)",
        choix:["Double authentification (2FA)","Repeindre les murs","Éteindre le wifi la nuit","Acheter un écran plus grand"],
        expl:"Même si le mot de passe est deviné, le 2e code bloque l'intrus." },
      { menace:"Un ordinateur est infecté et le virus veut se propager à tout le réseau.", bonne:"Segmentation du réseau",
        choix:["Segmentation du réseau","Un plus gros disque dur","Changer de clavier","Mettre de la musique"],
        expl:"Cloisonner le réseau empêche le virus de se propager partout." },
      { menace:"Un ransomware a chiffré tous les fichiers de l'entreprise.", bonne:"Sauvegardes (règle 3-2-1)",
        choix:["Sauvegardes (règle 3-2-1)","Payer tout de suite","Débrancher internet pour toujours","Attendre"],
        expl:"Avec une bonne sauvegarde, on restaure sans payer la rançon." },
      { menace:"On veut empêcher les connexions non autorisées d'entrer sur le réseau.", bonne:"Pare-feu",
        choix:["Pare-feu","Un antivol de vélo","Un mot de passe sur le micro-ondes","Rien"],
        expl:"Le pare-feu filtre ce qui entre et sort du réseau." },
      { menace:"On veut que les données volées sur un disque restent illisibles.", bonne:"Chiffrement",
        choix:["Chiffrement","Un gros cadenas sur la porte","Un post-it","Changer la couleur des fichiers"],
        expl:"Le chiffrement rend les données illisibles sans la clé." }
    ];
    let idx = 0, ok = 0;
    root.innerHTML = `<div id="def-zone"></div><div class="soc-counter">Menaces traitées : <span id="def-n">0</span>/5 — Correctes : <span id="def-ok">0</span></div>`;
    const zone = document.getElementById("def-zone");
    function shuffle(a){return a.map(v=>[Math.random(),v]).sort((x,y)=>x[0]-y[0]).map(p=>p[1]);}
    function show() {
      if (idx >= cas.length) {
        zone.innerHTML = `<div class="lab-result ${ok>=4?'success':'partial'}">
          ${ok>=4?"🎉 Bravo, architecte ! Tu sais associer chaque menace à sa défense.":"Presque ! Relis la leçon sur la défense en profondeur."} Score : ${ok}/5.</div>`;
        if (ok>=4) done();
        else { zone.innerHTML += `<div class="lab-btn-row"><button class="btn btn-primary" id="def-retry">↺ Réessayer</button></div>`;
               document.getElementById("def-retry").addEventListener("click", ()=>{idx=0;ok=0;upd();show();}); }
        return;
      }
      const c = cas[idx];
      zone.innerHTML = `
        <div class="alert-card" style="border-left-color:#8b5cf6">
          <div class="alert-icon">⚠️</div>
          <div class="alert-txt">${c.menace}</div>
        </div>
        <p class="lab-ask">Quelle protection choisis-tu ?</p>
        <div class="qbox-choices" id="def-choices">
          ${shuffle(c.choix).map(ch=>`<button class="qbox-choice" data-c="${ch.replace(/"/g,'&quot;')}">${ch}</button>`).join("")}
        </div>
        <div id="def-fb"></div>`;
      zone.querySelectorAll(".qbox-choice").forEach(btn=>{
        btn.addEventListener("click", ()=>{
          const chosen = btn.dataset.c;
          const correct = chosen === c.bonne;
          if (correct) ok++;
          idx++; upd();
          zone.querySelectorAll(".qbox-choice").forEach(b=>{b.disabled=true; if(b.dataset.c===c.bonne)b.classList.add("good"); else if(b===btn)b.classList.add("bad");});
          document.getElementById("def-fb").innerHTML =
            `<div class="lab-feedback ${correct?'good':'bad'}">${correct?"✔️ Excellent choix !":"✘ Pas idéal."} ${c.expl}
             <div style="margin-top:10px"><button class="btn btn-primary" id="def-next">Menace suivante →</button></div></div>`;
          document.getElementById("def-next").addEventListener("click", show);
        });
      });
    }
    function upd(){ document.getElementById("def-n").textContent=idx; document.getElementById("def-ok").textContent=ok; }
    show();
  }
}

};

/* ---------- Petit moteur de quiz réutilisable dans les labs ---------- */
function renderQuiz(container, questions, done) {
  let answered = 0, correct = 0;
  container.innerHTML = questions.map((q,i) => `
    <div class="qbox" data-qi="${i}">
      <p class="qbox-q">${i+1}. ${q.q}</p>
      <div class="qbox-choices">
        ${q.choix.map((c,j)=>`<button class="qbox-choice" data-j="${j}">${c}</button>`).join("")}
      </div>
      <div class="qbox-fb"></div>
    </div>`).join("");
  container.querySelectorAll(".qbox").forEach(box => {
    const qi = +box.dataset.qi;
    const q = questions[qi];
    box.querySelectorAll(".qbox-choice").forEach(btn => {
      btn.addEventListener("click", () => {
        if (box.classList.contains("done")) return;
        box.classList.add("done");
        const j = +btn.dataset.j;
        const fb = box.querySelector(".qbox-fb");
        box.querySelectorAll(".qbox-choice").forEach(b=>b.disabled=true);
        if (j === q.bonne) {
          btn.classList.add("good"); correct++;
          fb.innerHTML = `<span class="good">✔️ Correct !</span>`;
        } else {
          btn.classList.add("bad");
          box.querySelectorAll(".qbox-choice")[q.bonne].classList.add("good");
          fb.innerHTML = `<span class="bad">✘ La bonne réponse était surlignée en vert.</span>`;
        }
        answered++;
        if (answered === questions.length && correct >= Math.ceil(questions.length*0.6)) done();
      });
    });
  });
}

function markLabSuccess(root) {
  if (root.querySelector(".lab-success-banner")) return;
  const b = document.createElement("div");
  b.className = "lab-success-banner";
  b.innerHTML = "🏆 Lab validé ! Bravo.";
  root.prepend(b);
}
