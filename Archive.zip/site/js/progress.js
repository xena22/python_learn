/* ============================================================
   PROGRESSION — stockée dans le navigateur (localStorage)
   Aucune donnée ne quitte l'ordinateur. Zéro serveur à gérer.
   Structure : { nom, lecons:{}, qcm:{moduleId:score}, labs:{labId:true} }
   ============================================================ */

const PKEY = "cyberstage_progress_v1";

const Progress = {
  data: null,

  load() {
    try { this.data = JSON.parse(localStorage.getItem(PKEY)); } catch(e) { this.data = null; }
    if (!this.data) this.data = { nom:"", lecons:{}, qcm:{}, labs:{} };
    return this.data;
  },
  save() {
    try { localStorage.setItem(PKEY, JSON.stringify(this.data)); } catch(e) {}
  },
  setNom(n){ this.data.nom = n; this.save(); },

  markLecon(mid, idx){ this.data.lecons[`${mid}:${idx}`] = true; this.save(); },
  leconDone(mid, idx){ return !!this.data.lecons[`${mid}:${idx}`]; },

  setQcm(mid, score, total){ this.data.qcm[mid] = {score, total, ts:Date.now()}; this.save(); },
  getQcm(mid){ return this.data.qcm[mid] || null; },

  markLab(id){ this.data.labs[id] = true; this.save(); },
  labDone(id){ return !!this.data.labs[id]; },

  /* % global de progression sur toute la plateforme */
  globalPercent() {
    let total = 0, done = 0;
    MODULES.forEach(m => {
      m.lecons.forEach((_,i)=>{ total++; if (this.leconDone(m.id,i)) done++; });
      total++; if (this.getQcm(m.id)) done++;                 // QCM
      (m.labs||[]).forEach(id=>{ total++; if (this.labDone(id)) done++; });
    });
    return total ? Math.round(done/total*100) : 0;
  },

  moduleDone(m) {
    const lec = m.lecons.every((_,i)=>this.leconDone(m.id,i));
    const qcm = !!this.getQcm(m.id);
    const labs = (m.labs||[]).every(id=>this.labDone(id));
    return lec && qcm && labs;
  },

  reset(){ this.data = { nom:this.data.nom, lecons:{}, qcm:{}, labs:{} }; this.save(); },

  /* Export texte des résultats (pour montrer/envoyer au tuteur) */
  exportText() {
    let out = `=== RÉSULTATS CYBER-STAGE ===\nÉlève : ${this.data.nom || "(sans nom)"}\nDate : ${new Date().toLocaleString("fr-FR")}\nProgression globale : ${this.globalPercent()}%\n\n`;
    MODULES.forEach(m => {
      const q = this.getQcm(m.id);
      out += `• ${m.titre}\n`;
      out += `   QCM : ${q ? q.score+"/"+q.total : "non fait"}\n`;
      if ((m.labs||[]).length) {
        const ok = m.labs.filter(id=>this.labDone(id)).length;
        out += `   Labs : ${ok}/${m.labs.length} validés\n`;
      }
    });
    return out;
  }
};
